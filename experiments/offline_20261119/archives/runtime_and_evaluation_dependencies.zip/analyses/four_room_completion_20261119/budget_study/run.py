#!/usr/bin/env python3
"""Offline pilot only. No ROS, hardware, training, or import-time execution.

The immutable protocol declares a new scene, visible-label dictionary adapter,
and the existing joint policy's finite-budget / return contract.
"""
import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

STUDY = Path(__file__).resolve().parent
HERE = STUDY
SOURCE = Path('/home/ouc/nso_robot/analyses/reproduction_20261104/simulation_publication_stage/experiments/unknown_exploration_20261104/source')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    from nso.cpu_sensor_contract_v10 import json_value
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(json_value(value), ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def dependencies():
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    sys.path.insert(0, str(SOURCE))


def protocol():
    return json.loads((HERE / 'protocol.json').read_text())


def world_and_packet():
    import numpy as np
    from env.virtual3d_v2 import VirtualConfigV2, VirtualWorldV2
    from nso.cpu_sensor_contract_v10 import GridTransform
    cfg = protocol()
    world = VirtualWorldV2(VirtualConfigV2(**cfg['environment']['config']),
                           seed=cfg['environment']['seed'], layout='rooms',
                           semantic_condition='aligned')
    transform = GridTransform(tuple(world.shape), world.config.resolution_m)
    return world, transform, packet(world, transform, world.sense())


def packet(world, transform, raw_frame, action=None, collision=False, done=False):
    import numpy as np
    from nso.cpu_sensor_contract_v10 import SensorPacket
    # Dictionary alignment ONLY on labels of currently visible valid pixels.
    # V2: 2 solid, 3 shelf. V10 competition scorer: 2 shelf, 3 solid.
    labels = np.where(raw_frame.semantic == 2, 3,
                      np.where(raw_frame.semantic == 3, 2, raw_frame.semantic)).astype(np.uint8)
    assert np.all(labels[raw_frame.depth_m == 0] == 0)
    frame = dataclasses.replace(raw_frame, semantic=labels)
    cfg = protocol()
    return SensorPacket(cfg['scene_id'], 'first-frame-only', f'frame-{world.step_count}',
                        int(world.step_count), frame, world.scan(),
                        tuple(map(int, world.position)), int(world.heading),
                        'simulated_RGBD_scan_visible_semantics_dictionary_v1',
                        'simulated_exact_discrete_odometry', action,
                        bool(collision), bool(done)).validate(transform, world.config)


def source_hashes():
    return {str(p.relative_to(SOURCE)): sha(p) for p in sorted(SOURCE.rglob('*'))
            if p.is_file() and p.suffix in ('.py', '.json')}


def prepare():
    import numpy as np
    from nso.observed_runtime_mapper_v10 import ObservedRuntimeMapperV10
    out = HERE / 'prepared'
    out.mkdir(exist_ok=False)
    hashes = source_hashes()
    world, transform, p = world_and_packet()
    mapper = ObservedRuntimeMapperV10(world.shape, world.config)
    mapper.update(p.frame, p.scan)
    raw = world.sense()
    np.savez_compressed(out / 'initial_sensor.npz', depth_m=p.frame.depth_m,
                        rgb=p.frame.color_rgb, raw_visible_labels=raw.semantic,
                        adapted_visible_labels=p.frame.semantic,
                        scan_m=p.scan.ranges_m, world_from_camera=p.frame.world_from_camera)
    # Evaluator-only artifact. Never passed to the policy or its mapper.
    np.savez_compressed(out / 'evaluator_truth.npz', reachable=world.reachable,
                        occupancy=world.occupancy)
    known = float(np.count_nonzero((mapper.belief != -1) & world.reachable) / world.reachable.sum())
    regions = {}
    rr, cc = np.indices(world.shape)
    for name, mask in [('NW', (rr < world.shape[0]//2) & (cc < world.shape[1]//2)),
                       ('NE', (rr < world.shape[0]//2) & (cc >= world.shape[1]//2)),
                       ('SW', (rr >= world.shape[0]//2) & (cc < world.shape[1]//2)),
                       ('SE', (rr >= world.shape[0]//2) & (cc >= world.shape[1]//2))]:
        regions[name] = int(np.count_nonzero(mask & world.reachable))
    metadata = dict(scene_id=protocol()['scene_id'], status='prepared_no_paid_action',
                    independent_layouts=1, anchor=[*world.position, world.heading],
                    actual_config=dataclasses.asdict(world.config), object_count=len(world.objects),
                    initial_packet_sha256=p.sha256(), initial_coverage_fraction=known,
                    initial_unknown_fraction=1-known, reachable_free_area_m2=float(world.reachable.sum()*.04),
                    start_component_cells_by_quadrant=regions,
                    all_four_quadrants_connected=all(v > 0 for v in regions.values()),
                    raw_visible_label_pixels={str(v): int(np.count_nonzero(raw.semantic == v)) for v in (0,1,2,3)},
                    adapted_visible_label_pixels={str(v): int(np.count_nonzero(p.frame.semantic == v)) for v in (0,1,2,3)},
                    real_semantic_detector=False, motion_steps=int(world.step_count))
    write(out / 'initial_state.json', metadata)
    write(out / 'freeze.json', dict(protocol_sha256=sha(HERE/'protocol.json'),
                                    runner_sha256=sha(__file__), source_sha256=hashes,
                                    created_unix_s=time.time()))
    print(json.dumps(metadata), flush=True)


def verify():
    frozen = json.loads((HERE/'prepared/freeze.json').read_text())
    assert sha(HERE/'protocol.json') == frozen['protocol_sha256'], 'protocol changed'
    assert sha(__file__) == frozen['runner_sha256'], 'runner changed'
    assert source_hashes() == frozen['source_sha256'], 'science source changed'
    return json.loads((HERE/'prepared/initial_state.json').read_text())


def run(mode):
    import numpy as np
    from types import SimpleNamespace
    from nso.components import NSO_Components
    from nso_bridge.exploration_joint_policy import ExplorationJointCPUFourModules, ExplorationJointRuntimeIntegration
    initial = verify()
    cfg = protocol()
    out = HERE / 'runs' / mode
    out.mkdir(parents=True, exist_ok=False)  # Preserve every attempted slot.
    started = time.monotonic()
    write(out/'attempt.json', dict(mode=mode, started_unix_s=time.time(), protocol_sha256=sha(HERE/'protocol.json')))
    steps, choices, timings = [], [], []
    try:
        world, transform, p = world_and_packet()
        assert p.sha256() == initial['initial_packet_sha256'], 'first packet differs'
        args = SimpleNamespace(**cfg['policy']['args'], cpu_score_mode=mode, run_id='complex-pilot-'+mode)
        components = NSO_Components(args)
        components.initialize('cpu', 1, *world.shape, *world.shape)
        components._cpu_backend = ExplorationJointCPUFourModules(args, 1, world.shape)
        components.capabilities = dict(components._cpu_backend.capabilities)
        runtime = ExplorationJointRuntimeIntegration(components, 1, world.shape)
        anchor = (*p.position, p.heading)
        runtime.start_sensor_episode(0, config=world.config, transform=transform,
                                     packets=[p], total_budget=cfg['policy']['paid_action_budget'],
                                     return_anchor=anchor, paid_prefix_actions=0)
        mapper = runtime.states[0]['mapper']
        def coverage():
            return float(np.count_nonzero((mapper.belief != -1) & world.reachable) / world.reachable.sum())
        first_coverage = coverage()
        while not runtime.states[0]['closed']:
            t = time.monotonic()
            action = runtime.next_local_action(0)
            timings.append(time.monotonic()-t)
            choices = [dict(inputs=x['inputs'], outputs=x['outputs']) for x in components._cpu_backend.calls
                       if x['method'] == 'select_topo_target']
            write(out/'choices.json', choices)
            if action is None:
                break
            raw, collision, done = world.step(action)
            p = packet(world, transform, raw, action, collision, done)
            runtime.observe(0, world.step_count, None, None, None, sensor_packet=p)
            steps.append(dict(step=world.step_count, action=action, position=list(world.position),
                              heading=world.heading, coverage_fraction=coverage(),
                              path_length_m=world.moves*world.config.resolution_m,
                              collision=bool(collision), done=bool(done), packet_sha256=p.sha256(),
                              measured_patch_count=len(mapper.quality)))
            write(out/'steps.json', steps)
            write(out/'heartbeat.json', dict(step=world.step_count, elapsed_s=time.monotonic()-started))
        summary = runtime.sensor_episode_summary(0)
        write(out/'runtime_audit.json', runtime.audit)
        write(out/'episode_summary.json', summary)
        np.savez_compressed(out/'final_observed_map.npz', belief=mapper.belief,
                            camera_seen=mapper.camera_seen, position=np.asarray(world.position),
                            heading=np.asarray(world.heading))
        diagnostics=[]
        for record in choices:
            output=record['outputs']; audit=output['candidate_audit']
            diagnostics.append(dict(plan=output['plan_number'],
                paid_before=cfg['policy']['paid_action_budget']-audit['remaining_budget'],
                remaining_budget=audit['remaining_budget'], feasible_states=audit['feasible_states'],
                candidate_count=len(output['candidates']), status=audit['status'],
                minimum_current_return_cost=audit['minimum_current_return_cost'],
                coverage_scores=output['scores'].get('C', []), G_scores=output['scores'].get('G', []),
                selected_pose=None if output['selected'] is None else output['selected']['pose'],
                selected_outbound_cost=None if output['selected'] is None else output['selected']['outbound_cost'],
                selected_return_cost=None if output['selected'] is None else output['selected']['return_cost']))
        write(out/'plan_diagnostics.json', diagnostics)
        trace = json.dumps([(x['action'], x['position'], x['heading']) for x in steps], sort_keys=True).encode()
        result = dict(status='completed_execution', mode=mode, scene_id=cfg['scene_id'],
                      independent_layouts=1, paid_actions=len(steps), initial_coverage_fraction=first_coverage,
                      final_coverage_fraction=coverage(), coverage_gain_percentage_points=100*(coverage()-first_coverage),
                      path_length_m=world.moves*world.config.resolution_m,
                      turn_actions=sum(x['action'] in ('left','right') for x in steps), collisions=world.collisions,
                      termination=summary['termination'], initial_packet_sha256=initial['initial_packet_sha256'],
                      trajectory_sha256=hashlib.sha256(trace).hexdigest(), global_planning_calls=len(choices),
                      paid_action_budget=cfg['policy']['paid_action_budget'],
                      first_coverage_action={str(target): next((x['step'] for x in steps if x['coverage_fraction']>=target), None)
                                             for target in (0.90,0.95,0.99)},
                      decision_wall_seconds_total=sum(timings), elapsed_s=time.monotonic()-started,
                      reconstruction_accuracy_evaluated=False, measured_patch_count=len(mapper.quality),
                      surface_metric='record count only; not area, completeness or F1',
                      capabilities=components.capabilities, source_hashes_unchanged=source_hashes()==json.loads((HERE/'prepared/freeze.json').read_text())['source_sha256'])
        write(out/'result.json', result)
        print(json.dumps(result), flush=True)
    except BaseException as exc:
        write(out/'failure.json', dict(status='failed', error=repr(exc), traceback=traceback.format_exc(),
                                      paid_actions=len(steps), elapsed_s=time.monotonic()-started))
        raise


def main():
    global HERE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('prepare','verify','run'))
    parser.add_argument('--mode', choices=('C','G','S'))
    parser.add_argument('--budget', required=True, type=int, choices=(256,512))
    args = parser.parse_args()
    HERE=STUDY/f'budget_{args.budget}'
    dependencies()
    if args.command == 'prepare':
        prepare()
    elif args.command == 'verify':
        print(json.dumps(verify()))
    else:
        if args.mode is None:
            parser.error('run requires --mode; no implicit batch')
        if args.mode!='G':
            parser.error('this predeclared budget study executes G only')
        run(args.mode)


if __name__ == '__main__':
    main()
