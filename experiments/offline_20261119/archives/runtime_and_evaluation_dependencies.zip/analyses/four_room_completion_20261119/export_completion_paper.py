#!/usr/bin/env python3
"""Export measured offline evidence only. Interrupted S1024 remains partial."""
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np

ROOT=Path(__file__).resolve().parent
PAPER=Path('/home/ouc/nso_robot/workspaces/nso_research_20261029/NSO/docs/thesis/submission_focus_20261108')
OLD=Path('/home/ouc/nso_robot/analyses/paper_revision_20261119/unknown_exploration_pilot')
ARMS=('C','G','S','X','G2','S_gainFrozen')
LABELS={'C':'C','G':'G','S':'S','X':'X (reversed cue)','G2':r'G, $2\times$ prior','S_gainFrozen':'S, frozen gain'}
SEEDS=(20261119,20261120,20261121)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pct(x):return f'{100*x:.2f}'


def main():
    a=read(ROOT/'matrix_summary.json')
    assert a['status']=='complete' and a['completed_results']==18 and not a['failures']
    rows={(x['seed'],x['arm']):x for x in a['rows']}
    assert len(rows)==18 and all(x['reconstruction'] is not None for x in rows.values())
    for seed in SEEDS:
        assert len({rows[seed,arm]['initial_packet_sha256'] for arm in ARMS})==1
        assert len({rows[seed,arm]['reconstruction']['reference_points_and_classes_sha256'] for arm in ARMS})==1
    budgets=[]
    for budget,case in [(96,OLD)]+[(n,ROOT/'budget_study'/f'budget_{n}') for n in (256,512,1024)]:
        budgets.append((budget,case,read(case/'runs/G/result.json')))
    sdir=ROOT/'budget_study/budget_1024/runs/S'
    interrupted=read(sdir/'interruption_receipt.json')
    assert not (sdir/'result.json').exists() and interrupted['process_exit_code']==143
    ssteps=read(sdir/'steps.json')
    assert len(ssteps)==interrupted['paid_actions_saved']==398
    lastcase=budgets[-1][1];gres=budgets[-1][2];gsteps=read(lastcase/'runs/G/steps.json')
    first100=next(s for s in gsteps if s['coverage_fraction']==1.)
    gt=np.load(lastcase/'prepared/evaluator_truth.npz');lastmap=np.load(lastcase/'runs/G/final_observed_map.npz')
    assert gres['final_coverage_fraction']==1. and not np.any((lastmap['belief']==1)&gt['reachable'])
    assert gres['collisions']==0 and gres['termination']['returned_to_anchor']
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(9.4,3.35),constrained_layout=True)
    for (budget,case,res),color in zip(budgets,('#999999','#009E73','#0072B2','#D55E00')):
        steps=read(case/'runs/G/steps.json');curve=[res['initial_coverage_fraction']]+[s['coverage_fraction'] for s in steps]
        axes[0].plot(range(len(curve)),100*np.array(curve),label=f'G, budget {budget}',color=color)
    scurve=[gres['initial_coverage_fraction']]+[s['coverage_fraction'] for s in ssteps]
    axes[0].plot(range(len(scurve)),100*np.array(scurve),'--',color='#CC79A7',label='S/1024, interrupted at 398')
    axes[0].plot(398,100*scurve[-1],'x',color='#CC79A7',ms=6)
    axes[0].set(xlabel='Paid actions',ylabel='Reachable-cell coverage (%)',ylim=(0,101));axes[0].grid(alpha=.2);axes[0].legend(frameon=False,fontsize=7.2,loc='lower right')
    initial=read(lastcase/'prepared/initial_state.json');res=initial['actual_config']['resolution_m'];h,w=np.array(gt['occupancy'].shape)*res
    im=np.where(gt['occupancy'],.18,np.where(gt['reachable'],.96,.65))
    axes[1].imshow(im,origin='upper',extent=(0,w,0,h),cmap='gray',vmin=0,vmax=1)
    xy=np.array([initial['anchor'][:2]]+[s['position'] for s in gsteps])
    axes[1].plot((xy[:,1]+.5)*res,h-(xy[:,0]+.5)*res,color='#D55E00',lw=.8,label='G/1024, completed')
    axes[1].plot((xy[0,1]+.5)*res,h-(xy[0,0]+.5)*res,'o',color='black',ms=4)
    axes[1].set(xlabel='x (m)',ylabel='y (m)',aspect='equal');axes[1].legend(frameon=False,fontsize=8)
    fig.savefig(ROOT/'budget_diagnosis.pdf');fig.savefig(ROOT/'budget_diagnosis.png',dpi=170);plt.close(fig)
    shutil.copy2(ROOT/'budget_diagnosis.pdf',PAPER/'Four_room_budget_20261119.pdf')
    shutil.copy2(ROOT/'matrix_coverage_trajectories.pdf',PAPER/'Four_room_matrix_20261119.pdf')
    text=[r'\paragraph{Budget sufficiency and fixed-cost comparison.}',
      r'The development pilot is extended without changing its candidates, scores or execution rules. G attains 85.18\%, 93.38\% and 100\% coverage at budgets 256, 512 and 1024, respectively (Figure~\ref{fig:four-room-budget}). It first covers all free cells in the start-reachable reference at action 727 after 135.0 m; the complete 1024-action episode travels 189.6 m and returns without collision or false occupied labels on that reference. These are one-layout budget diagnostics. A matched S/1024 attempt receives SIGTERM after 398 actions and 93.38\% last-observed coverage; its cause is undetermined, and no terminal outcome or policy failure is assigned.',
      r'\begin{figure}[!htbp]\centering\includegraphics[width=.94\linewidth]{Four_room_budget_20261119.pdf}',
      r'\caption{Development budget diagnostics, retaining the shorter incomplete trials. The interrupted S curve ends at its last actual observation. Right: the completed G/1024 trajectory over evaluator-only geometry. Full coverage is a measured checkpoint, separate from the later return.}\label{fig:four-room-budget}\end{figure}',
      r'A separate frozen protocol compares six arms at a common 512-action cap on three generated object layouts: the inspected development layout D and two new layouts E1/E2, all sharing one four-room wall topology. Each paired set begins with an identical single sensor packet and exact pose. C scores unknown coverage; G adds measured quality and a generic structural prior; S uses category-conditioned priors; X reverses that interpretation. G2 doubles only the generic prior. S with frozen gain disables only the radar/camera posterior update while retaining fusion and directional histories. All eighteen runs are retained (Table~\ref{tab:four-room-matrix}); they represent three layouts, not eighteen independent environments.',
      r'The renderer supplies constant-gray valid RGB pixels and ideal visible category labels. Objects occupy regularly arranged slots, with no natural-image detector or measured real-world category distribution. These scenes test a synthetic planning mechanism, not realistic semantic perception. Neither the complete two-template posterior nor a trained reachability network runs in this joint variant.',
      r'Native measured-depth TSDF meshes use 6 cm voxels and 12 cm truncation. A fixed reference samples the exterior box-union boundary, excluding internal faces, and retains surfaces visible from a 0.8 m lattice of reachable camera origins. Reconstructed-area precision and fixed-reference recall at 5 cm yield surface F1~\cite{ref14}. The reference is independent of each trajectory; the supplementary protocol specifies its sampling and visibility limits.',
      r'\begin{table}[!htbp]\centering\small',
      r'\caption{All eighteen outcomes at a common 512-action cap. Entries are reachable-cell coverage / surface F1 at 5 cm, both in percent. D is development; E1/E2 are new object layouts of the same topology.}\label{tab:four-room-matrix}',
      r'\begin{tabular}{@{}lrrr@{}}\toprule Policy & D: Coverage/F1 & E1: Coverage/F1 & E2: Coverage/F1 \\ \midrule']
    for arm in ARMS:
        values=[f"{pct(rows[seed,arm]['final_coverage'])}/{pct(rows[seed,arm]['reconstruction']['metrics']['f1_05cm'])}" for seed in SEEDS]
        text.append(LABELS[arm]+' & '+' & '.join(values)+r' \\')
    text += [r'\bottomrule\end{tabular}\end{table}',
      r'C exceeds G and S in both coverage and F1 on all three layouts; X also exceeds S in F1 throughout. G/S trajectories coincide in D/E2. In E1 they differ but finish with equal coverage, while S lowers F1 by 0.083 percentage points; its normalized coverage-curve area increases by only 0.000968. G2 reproduces G in all three layouts. Freezing the gain posterior improves F1 only in D, with unchanged coverage. These outcomes provide no consistent benefit from the semantic prior or gain calibration.',
      r'\begin{figure}[!htbp]\centering\includegraphics[width=.94\linewidth]{Four_room_matrix_20261119.pdf}',
      r'\caption{Fixed-cost coverage histories and G/S trajectories for D/E1/E2. Background geometry is evaluator-only. The full table retains the additional controls; repeated checkpoints are dependent measurements.}\label{fig:four-room-matrix}\end{figure}',
      r'A post-hoc audit nevertheless distinguishes ranking from utility. For E1, four recorded S choices cannot be reproduced by any nonnegative weight in $\mathrm{common}+\lambda\,\mathrm{prior}_G$, even separately at each state, with the original cost/id tie rule. D/E2 admit uniform weights including 1 and 2. Category-conditioned ranking therefore operates in E1 without an observed endpoint benefit. On D, replay of the 98-action zero-coverage segment raises surface F1 from 88.185\% to 88.930\%: observation is useful locally but inefficient relative to the coverage control. Detailed score intervals, reference construction and replay results are retained in the supplement.']
    # Keep the last diagram inside the exploration subsection.
    text[-3:] = [text[-1], text[-3].replace('[!htbp]', '[H]'), text[-2]]
    (PAPER/'four_room_completion_20261119.tex').write_text('\n\n'.join(text)+'\n')
    detail=[r'\section{Four-room budget and six-arm diagnostics}',
      r'This extension concerns exploration\_joint\_v1/v10\_3\_1, not the supplied-graph V35 method. Three object-layout seeds are fixed at 20261119 (development), 20261120 and 20261121. They share one wall-topology family, one initial-view rule, ideal visible semantic labels and exact odometry. The default gray RGB pixels do not support an evaluation of natural-image recognition. The scene uses regularly arranged object slots rather than a distribution estimated from real rooms. Expanding the category list or adding textures alone would not establish realistic semantic distributions.',
      r'\subsection{Budget and interruption accounting}',
      r'All completed G diagnostics retain the fixed-anchor return contract. Their different budgets are not additional independent environments. The S/1024 process ends with exit code 143 after SIGTERM, with 398 accepted actions and 93.3816\% last coverage. No result or verified final return exists; the interruption has no established sender/cause and is not classified as an algorithmic failure.',
      r'\begin{table}[!htbp]\centering\small\caption{All completed G budget diagnostics. Dashes denote thresholds not reached. Distance is the full episode, including return.}\label{tab:s-four-room-budget}',
      r'\begin{tabular}{@{}rrrrrrr@{}}\toprule Budget & Executed & Coverage (\%) & First 95\% & First 99\% & First 100\% & Distance (m) \\ \midrule']
    for budget,case,res in budgets:
        steps=read(case/'runs/G/steps.json');hits=[next((s['step'] for s in steps if s['coverage_fraction']>=t),'--') for t in (.95,.99,1.)]
        detail.append(f"{budget} & {res['paid_actions']} & {pct(res['final_coverage_fraction'])} & {hits[0]} & {hits[1]} & {hits[2]} & {res['path_length_m']:.1f}"+r' \\')
    detail += [r'\bottomrule\end{tabular}\end{table}',
      r'The 96-action pilot stops gaining coverage at action 53, leaving 43 actions while the minimum return needs 41. In the 512/1024 pair, the first 366 actions and sensor-packet hashes, belief map and safe-grid hashes coincide. At that state, the longer-budget run selects a route with 92 outbound and 78 return actions. Its 170-action round trip is infeasible under the shorter run\textquotesingle s remaining 146 actions. Thus, a comparison restricted to the 512-action candidate set cannot attribute the plateau solely to score ordering. G/1024 first reaches full coverage at action 727 and 135.0 m; its final 1024-action return is a separate event.',
      r'\subsection{Surface reference and fairness}',
      r'The evaluator constructs the exterior boundary of the simulator axis-aligned box union, removing internal and duplicate coplanar faces. It draws 100,000 area-weighted samples with seed 20261119; a fixed 0.8 m lattice of start-reachable camera origins and a first-hit ray test retain the sensor-observable reference. The reference permits arbitrary planar yaw and is an approximation to observation opportunity on that fixed lattice, not all exterior surface. D retains 56,620 reference points. Precision uses 12,000 area-weighted reconstructed samples with seed 812 and distance to exterior triangles; recall uses the reverse distance from the fixed reference to the reconstructed mesh. Thresholds are 5 and 10 cm. This is a local adaptation of thresholded surface comparison, not an official benchmark score. No geometric alignment to the reference is performed.',
      r'All arms share 512-action caps, return and collision rules, candidate generation, initial packet and per-layout reference hashes. C is a coverage-only score on the same candidate generator, not an external frontier implementation. G2 multiplies the generic prior by two without scaling the public common term. The frozen-gain arm retains camera history, direction observations and mapping. Every completed attempt and its artifacts are hashed; the development G mesh is additionally reproduced from all 513 packets, with identical coverage at every frame and identical final mesh vertices and triangles. Known-cell coverage can include false occupied labels on the free reference, so the records also retain those errors and per-room coverage. Coverage-curve area uses trapezoidal integration over the common budget, holding the final observation after an early stop without inventing actions.',
      r'\subsection{Same-state scalar explainability}',
      r'For each recorded S winner $w$, the audit solves all inequalities $c_w+\lambda p_w\ge c_j+\lambda p_j$ for $\lambda\ge0$, using strict inequality whenever the original full-round-trip-cost/id tie rule favors $j$. A selected score must be positive. Recorded binary floating-point values are represented as exact rationals for interval intersection; interior solutions are checked with the original floating-point selector. This is a post-hoc analysis of S states, not an additional weighted trajectory.',
      r'\begin{table}[!htbp]\centering\small\caption{Weights reproducing every recorded S choice in each layout. Counts are planning calls, not independent samples.}\label{tab:s-four-room-scalar}',
      r'\begin{tabular}{@{}lrl@{}}\toprule Layout & Calls & Feasible common $\lambda$ interval \\ \midrule',
      r'D & 21 & $[0.838004716,\,2.082011542]$ \\',
      r'E1 & 15 & Empty \\',
      r'E2 & 17 & $(0.806291688,\,6.089982889]$ \\',
      r'All three & 53 & Empty \\ \bottomrule\end{tabular}\end{table}',
      r'E1 decisions after actions 198, 373, 408 and 464 each have an empty feasible interval. At action 373, the S winner has $(c,p_G)=(0.883156,5.107287)$ while another candidate has $(1.146875,5.665380)$ and therefore strictly dominates it for every nonnegative scalar weight. Category-conditioned priors reverse their ordering, but this decision effect produces no terminal coverage improvement and slightly lower F1. The result excludes this scalar explanation only, not richer geometric decision models.',
      r'\subsection{Predicted and realized surface benefit}',
      r'In D, G/S have identical complete traces. Replaying the 98-action segment from action 366 to 464 yields zero reference coverage gain but raises 5 cm recall from 79.1169\% to 80.2490\% and F1 from 88.1847\% to 88.9299\%. It adds 886 measured 15 cm patch keys; among the fixed 1,600 old points used by the quality proxy, 241 acquire a new direction and 255 improve measured information. Patch counts are not surface area or accuracy. Holding the starting assets and route fixed while updating only their measured direction support reduces generic prior value from 7.2256 to 5.7445 and category prior value from 9.4781 to 7.8134. The prior is consumed partially, leaving a large residual. The preceding 92-action segment gains 4.2476 coverage percentage points and 4.1613 F1 points, so local observation benefit does not establish efficient allocation.',
      r'The coverage posteriors at action 366 are 0.97778 for radar and 0.07990 for camera. These are conditional yields of predicted cells, not calibrated sensor correctness: the episode realizes 483 of 493 predicted radar events and 30 of 386 predicted camera events, while also recording 3,438 and 952 unpredicted new-cell events. The old-quality score deduplicates route observations by pointwise maximum; its route-cost normalization cancels when converted back to total gain. No repeated-sum or sorting error is found. Candidate limitation, uncalibrated structural residuals and the observation--coverage tradeoff remain distinct explanations. Calibrating structural priors against actual new support is a proposed method change, not an implemented correction or a result of this experiment.']
    (PAPER/'four_room_completion_supplement_20261119.tex').write_text('\n\n'.join(detail)+'\n')
    outputs=['four_room_completion_20261119.tex','four_room_completion_supplement_20261119.tex','Four_room_budget_20261119.pdf','Four_room_matrix_20261119.pdf']
    manifest=dict(matrix_summary_sha256=sha(ROOT/'matrix_summary.json'),export_script_sha256=sha(__file__),
        outputs={p:sha(PAPER/p) for p in outputs},slots=18,development_layouts=1,new_layouts=2,
        S1024_status='SIGTERM_interrupted_no_final_result',S1024_interruption_receipt_sha256=sha(sdir/'interruption_receipt.json'),
        physical_evidence=False,scientific_source_modified=False)
    (ROOT/'paper_export_receipt.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
