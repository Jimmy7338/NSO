#!/usr/bin/env python3
"""Summarize immutable completed offline trials; never runs a robot or policy."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
MATRIX = ROOT / 'matrix_study'
ARMS = ('C', 'G', 'S', 'X', 'G2', 'S_gainFrozen')
SEEDS = (20261119, 20261120, 20261121)


def read(p):
    return json.loads(Path(p).read_text())


def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def rows():
    output = []
    for seed in SEEDS:
        scene = MATRIX / 'scenes' / str(seed)
        for arm in ARMS:
            attempts = sorted((scene / 'runs' / arm).glob('attempt_*/result.json'))
            for path in attempts:
                r = read(path)
                steps = read(path.with_name('steps.json'))
                initial = read(scene / 'prepared' / 'initial_state.json')
                curve = np.array([initial['evaluation']['coverage_fraction']] + [s['coverage_fraction'] for s in steps])
                budget = r['paid_action_budget']
                assert len(curve) <= budget + 1
                # After early stop, retain last measured map; do not create actions.
                padded = np.pad(curve, (0, budget + 1 - len(curve)), constant_values=curve[-1])
                auc = float(np.sum((padded[1:] + padded[:-1]) / 2) / budget)
                row = dict(seed=seed, role='development' if seed == SEEDS[0] else 'new_layout',
                           arm=arm, attempt=path.parent.name, result_path=str(path),
                           result_sha256=digest(path), steps_sha256=digest(path.with_name('steps.json')),
                           status=r['status'], paid_actions=r['paid_actions'], budget=budget,
                           initial_coverage=float(curve[0]), final_coverage=float(curve[-1]),
                           normalized_coverage_auc=auc, path_length_m=r['path_length_m'],
                           turn_actions=r['turn_actions'], collisions=r['collisions'],
                           termination=r['termination'], initial_packet_sha256=r['initial_packet_sha256'],
                           first_coverage_action={str(t): next((i for i,v in enumerate(curve) if v >= t), None)
                                                  for t in (.9, .95, .99)},
                           reconstruction=None)
                eval_path = ROOT / 'surface_evaluation' / 'matrix' / str(seed) / arm / 'result.json'
                if eval_path.exists():
                    row['reconstruction'] = read(eval_path)
                    row['reconstruction_sha256'] = digest(eval_path)
                output.append(row)
    return output


def main():
    records = rows()
    failures = [str(p) for p in MATRIX.glob('scenes/*/runs/*/attempt_*/failure.json')]
    pairs = []
    for seed in SEEDS:
        matched = {r['arm']: r for r in records if r['seed'] == seed and r['attempt'] == 'attempt_001'}
        if 'G' in matched and 'S' in matched:
            g,s = matched['G'],matched['S']
            assert g['budget'] == s['budget'] == 512
            assert g['initial_packet_sha256'] == s['initial_packet_sha256']
            pairs.append(dict(seed=seed, role=g['role'],
                              coverage_difference_pp=100*(s['final_coverage']-g['final_coverage']),
                              auc_difference=s['normalized_coverage_auc']-g['normalized_coverage_auc']))
    summary = dict(status='complete' if len(records)==18 and not failures else 'partial',
                   intended_slots=18, completed_results=len(records), independent_layouts_available=len(set(r['seed'] for r in records)),
                   independent_new_layouts_available=len(set(r['seed'] for r in records if r['role']=='new_layout')),
                   rows=records, gs_pairs=pairs, failures=failures,
                   unit='procedurally varied four-room layout; same generator family; development scene is separate',
                   coverage_definition='known (free or occupied) intersection evaluator start-reachable free-cell set',
                   auc_definition='trapezoid area divided by common action budget; last measured value held after early termination')
    (ROOT / 'matrix_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (ROOT / 'matrix_endpoints.csv').open('w') as f:
        fields=['seed','role','arm','attempt','status','paid_actions','budget','initial_coverage','final_coverage',
                'normalized_coverage_auc','path_length_m','turn_actions','collisions']
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
    if not records:
        print(json.dumps({'completed':0}));return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(2,3,figsize=(11,6.4),constrained_layout=True)
    styles={'C':('#009E73',':'),'G':('#0072B2','-'),'S':('#D55E00','--')}
    for col,seed in enumerate(SEEDS):
        scene=MATRIX/'scenes'/str(seed)
        axes[0,col].set(title=('Development' if col==0 else f'New layout {col}'),
                        xlabel='Paid actions',ylabel='Reachable-cell coverage (%)',xlim=(0,512),ylim=(0,101))
        axes[0,col].grid(alpha=.18)
        if not (scene/'prepared/evaluator_truth.npz').exists():continue
        gt=np.load(scene/'prepared/evaluator_truth.npz')
        initial=read(scene/'prepared/initial_state.json')
        resolution=initial['actual_config']['resolution_m']
        h,w=gt['occupancy'].shape;h*=resolution;w*=resolution
        grid=np.where(gt['occupancy'],.18,np.where(gt['reachable'],.97,.7))
        axes[1,col].imshow(grid,origin='upper',extent=(0,w,0,h),cmap='gray',vmin=0,vmax=1)
        axes[1,col].set(xlabel='x (m)',ylabel='y (m)',aspect='equal')
        for arm,(color,style) in styles.items():
            rr=[r for r in records if r['seed']==seed and r['arm']==arm and r['attempt']=='attempt_001']
            if not rr:continue
            steps=read(Path(rr[0]['result_path']).with_name('steps.json'))
            curve=[initial['evaluation']['coverage_fraction']]+[s['coverage_fraction'] for s in steps]
            axes[0,col].plot(range(len(curve)),100*np.array(curve),style,color=color,lw=1.7,label=arm)
            if arm in ('G','S'):
                xy=np.array([initial['anchor'][:2]]+[s['position'] for s in steps])
                axes[1,col].plot((xy[:,1]+.5)*resolution,h-(xy[:,0]+.5)*resolution,
                                 style,color=color,lw=1.05,label=arm)
        start=initial['anchor']
        axes[1,col].plot((start[1]+.5)*resolution,h-(start[0]+.5)*resolution,'o',color='black',ms=4)
        axes[0,col].legend(frameon=False,loc='lower right')
        axes[1,col].legend(frameon=False,loc='lower right')
    fig.savefig(ROOT/'matrix_coverage_trajectories.pdf')
    fig.savefig(ROOT/'matrix_coverage_trajectories.png',dpi=160)
    plt.close(fig)
    print(json.dumps({'completed':len(records),'failures':len(failures),'pairs':pairs},indent=2))


if __name__=='__main__':main()
