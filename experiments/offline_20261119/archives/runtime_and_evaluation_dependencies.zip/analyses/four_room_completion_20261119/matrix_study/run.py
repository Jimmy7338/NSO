#!/usr/bin/env python3
"""Offline six-arm study. Explicit single-arm execution; no ROS or hardware.

prepare/verify/selfcheck execute no simulator actions. run requires a seed and
arm. Every attempt gets a new directory, including interrupted/failed attempts.
"""
import argparse
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
SOURCE = Path('/home/ouc/nso_robot/analyses/reproduction_20261104/simulation_publication_stage/experiments/unknown_exploration_20261104/source')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    from nso.cpu_sensor_contract_v10 import json_value
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(json_value(value), ensure_ascii=False, indent=2,
                               allow_nan=False) + '\n')
    temp.replace(path)


def dependencies():
    for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
        os.environ[key] = '1'
    sys.path.insert(0, str(SOURCE))


def protocol():
    return json.loads((HERE / 'protocol.json').read_text())


def scene_path(seed):
    return HERE / 'scenes' / str(seed)


def source_hashes():
    return {str(p.relative_to(SOURCE)): sha(p) for p in sorted(SOURCE.rglob('*'))
            if p.is_file() and p.suffix in ('.py', '.json')}


def packet(world, transform, raw, seed, action=None, collision=False, done=False):
    import numpy as np
    from nso.cpu_sensor_contract_v10 import SensorPacket
    labels = np.where(raw.semantic == 2, 3,
                      np.where(raw.semantic == 3, 2, raw.semantic)).astype(np.uint8)
    assert np.all(labels[raw.depth_m == 0] == 0)
    frame = dataclasses.replace(raw, semantic=labels)
    return SensorPacket(protocol()['scenes'][str(seed)]['scene_id'], 'first-frame-only',
                        f'frame-{world.step_count}', int(world.step_count), frame,
                        world.scan(), tuple(map(int, world.position)), int(world.heading),
                        'simulated_RGBD_scan_visible_semantics_dictionary_v1',
                        'simulated_exact_discrete_odometry', action, bool(collision),
                        bool(done)).validate(transform, world.config)


def world_and_packet(seed):
    from env.virtual3d_v2 import VirtualConfigV2, VirtualWorldV2
    from nso.cpu_sensor_contract_v10 import GridTransform
    cfg = protocol()['environment']
    world = VirtualWorldV2(VirtualConfigV2(**cfg['config']), seed=seed,
                           layout=cfg['layout'], semantic_condition=cfg['semantic_condition'])
    tr = GridTransform(tuple(world.shape), world.config.resolution_m)
    return world, tr, packet(world, tr, world.sense(), seed)


def region_masks(shape):
    import numpy as np
    rr, cc = np.indices(shape)
    return {'NW': (rr < shape[0]//2) & (cc < shape[1]//2),
            'NE': (rr < shape[0]//2) & (cc >= shape[1]//2),
            'SW': (rr >= shape[0]//2) & (cc < shape[1]//2),
            'SE': (rr >= shape[0]//2) & (cc >= shape[1]//2)}


def evaluate_belief(belief, reachable):
    """Evaluator-only ground truth. Never pass this result back to the actor."""
    import numpy as np
    def within(mask):
        count = int(np.count_nonzero(mask))
        known = int(np.count_nonzero((belief != -1) & mask))
        free = int(np.count_nonzero((belief == 0) & mask))
        occupied = int(np.count_nonzero((belief == 1) & mask))
        return dict(reference_free_cells=count, known_cells=known,
                    correctly_free_cells=free, false_occupied_cells=occupied,
                    coverage_fraction=known/count if count else None,
                    free_correct_fraction=free/count if count else None,
                    false_occupied_fraction=occupied/count if count else None)
    result = within(reachable)
    result['per_room'] = {name: within(mask & reachable)
                          for name, mask in region_masks(belief.shape).items()}
    return result


def prepare(seed):
    import numpy as np
    from nso.observed_runtime_mapper_v10 import ObservedRuntimeMapperV10
    out = scene_path(seed) / 'prepared'
    out.mkdir(parents=True, exist_ok=False)
    world, tr, p = world_and_packet(seed)
    mapper = ObservedRuntimeMapperV10(world.shape, world.config)
    mapper.update(p.frame, p.scan)
    np.savez_compressed(out/'initial_sensor.npz', depth_m=p.frame.depth_m,
                        rgb=p.frame.color_rgb, adapted_visible_labels=p.frame.semantic,
                        scan_m=p.scan.ranges_m, intrinsic=p.frame.intrinsic,
                        world_from_camera=p.frame.world_from_camera)
    np.savez_compressed(out/'evaluator_truth.npz', reachable=world.reachable,
                        occupancy=world.occupancy)
    cfg = protocol()
    initial = dict(seed=seed, scene_id=cfg['scenes'][str(seed)]['scene_id'],
                   scene_role=cfg['scenes'][str(seed)]['role'],
                   anchor=[*world.position, world.heading],
                   actual_config=dataclasses.asdict(world.config),
                   initial_packet_sha256=p.sha256(), object_count=len(world.objects),
                   evaluation=evaluate_belief(mapper.belief, world.reachable),
                   motion_steps=int(world.step_count), natural_semantic_detector=False)
    assert world.step_count == 0
    write(out/'initial_state.json', initial)
    write(out/'freeze.json', dict(protocol_sha256=sha(HERE/'protocol.json'),
                                  runner_sha256=sha(__file__), source_sha256=source_hashes(),
                                  initial_sensor_file_sha256=sha(out/'initial_sensor.npz'),
                                  truth_file_sha256=sha(out/'evaluator_truth.npz'),
                                  created_unix_s=time.time()))
    print(json.dumps(initial), flush=True)


def verify(seed):
    out = scene_path(seed)/'prepared'
    frozen = json.loads((out/'freeze.json').read_text())
    assert sha(HERE/'protocol.json') == frozen['protocol_sha256'], 'protocol changed'
    assert sha(__file__) == frozen['runner_sha256'], 'runner changed'
    assert source_hashes() == frozen['source_sha256'], 'scientific source changed'
    assert sha(out/'initial_sensor.npz') == frozen['initial_sensor_file_sha256']
    assert sha(out/'evaluator_truth.npz') == frozen['truth_file_sha256']
    return json.loads((out/'initial_state.json').read_text())


def backend_class(arm):
    from nso_bridge.exploration_joint_policy import ExplorationJointCPUFourModules
    if arm != 'G2':
        return ExplorationJointCPUFourModules
    class GWeight2Prospective(ExplorationJointCPUFourModules):
        policy_variant = 'exploration_joint_v1_G_weight2_prospective_N19'
        def _scores_v10_1(self, state, routes, attempted):
            scores, audit = super()._scores_v10_1(state, routes, attempted)
            for i, row in enumerate(audit):
                common, prior = row['common_total_proxy'], row['prior_potentials']['G']
                assert abs(scores['G'][i]-(common+prior)) < 1e-9
                scores['G'][i] = common+2.0*prior
                row['declared_G2_control'] = dict(common=common, prior_G=prior,
                                                  multiplier=2.0, total=scores['G'][i])
            return scores, audit
    return GWeight2Prospective


def bootstrap(seed, arm):
    from types import SimpleNamespace
    from nso.components import NSO_Components
    from nso_bridge.exploration_joint_policy import ExplorationJointRuntimeIntegration
    cfg = protocol(); arm_cfg = cfg['arms'][arm]
    world, tr, p = world_and_packet(seed)
    effective = dict(cfg['policy']['args'])
    effective.update(cpu_score_mode=arm_cfg['score_mode'],
                     cpu_freeze_gain_posterior=arm_cfg['gain_frozen'],
                     run_id=f'N19-{seed}-{arm}')
    args = SimpleNamespace(**effective)
    comp = NSO_Components(args)
    comp.initialize('cpu', 1, *world.shape, *world.shape)
    comp._cpu_backend = backend_class(arm)(args, 1, world.shape)
    comp.capabilities = dict(comp._cpu_backend.capabilities)
    runtime = ExplorationJointRuntimeIntegration(comp, 1, world.shape)
    runtime.start_sensor_episode(0, config=world.config, transform=tr, packets=[p],
                                 total_budget=cfg['policy']['paid_action_budget'],
                                 return_anchor=(*p.position, p.heading), paid_prefix_actions=0)
    state = comp._cpu_backend.scenes[0]
    assert state['ledger'].feedback_enabled is True
    assert state['gain'].feedback_enabled is (not arm_cfg['gain_frozen'])
    assert state['gain'].consume_predicted_attempts is False
    assert args.cpu_force_gain_feedback is False
    assert args.cpu_disable_feedback is False
    assert world.config.max_steps == cfg['policy']['paid_action_budget']
    assert comp._cpu_backend.planner_revision == 'v10_3_1'
    audit = dict(arm=arm, effective_args=effective, backend=type(comp._cpu_backend).__name__,
                 policy_variant=comp._cpu_backend.policy_variant,
                 gain_feedback_enabled=state['gain'].feedback_enabled,
                 history_feedback_enabled=state['ledger'].feedback_enabled,
                 consume_predicted_attempts=state['gain'].consume_predicted_attempts,
                 generic_prior_multiplier=arm_cfg['generic_prior_multiplier'],
                 initial_packet_sha256=p.sha256(), capabilities=comp.capabilities)
    return world, tr, p, comp, runtime, audit


def selfcheck(seed):
    """Check actual first-state scoring and flag consumers, with zero motion."""
    import numpy as np
    from nso.cpu_sensor_contract_v10 import digest
    initial = verify(seed); rows = {}; signatures = []
    for arm in protocol()['arms']:
        world, tr, p, comp, runtime, effective = bootstrap(seed, arm)
        assert p.sha256() == initial['initial_packet_sha256']
        comp._cpu_backend.select_target(0)
        state = comp._cpu_backend.scenes[0]; output = state['last_selection']
        candidate_hash = digest(output['candidates'])
        belief_hash = digest(runtime.states[0]['mapper'].belief)
        assert world.step_count == 0
        signatures.append((candidate_hash, belief_hash))
        rows[arm] = dict(effective=effective, candidate_sha256=candidate_hash,
                         belief_sha256=belief_hash, first_plan=output,
                         paid_actions=0, world_motion_steps=0)
        # An isolated calibration object verifies switch consumption without
        # inserting synthetic observations into the simulator or any run record.
        from copy import deepcopy
        gain = deepcopy(state['gain'])
        mapper = runtime.states[0]['mapper']
        predicted = np.ones(world.shape, bool)
        gain._pending[-1] = dict(radar=predicted, camera=predicted,
                                known_before=np.zeros(world.shape, bool),
                                camera_before=np.zeros(world.shape, bool))
        before = (dict(gain.alpha), dict(gain.beta))
        gain.observe(mapper, action_id=-1)
        after = (dict(gain.alpha), dict(gain.beta))
        assert (before == after) is (arm == 'S_gainFrozen')
        rows[arm]['isolated_gain_switch_unit_check'] = 'passed; no actor or world mutation'
    assert len(set(signatures)) == 1, 'first-state candidates/geometry differ'
    base = rows['G']['first_plan']
    for i, a in enumerate(base['score_audit']):
        assert abs(base['scores']['G'][i]-(a['common_total_proxy']+a['prior_potentials']['G'])) < 1e-9
        assert abs(rows['G2']['first_plan']['scores']['G'][i]-(a['common_total_proxy']+2*a['prior_potentials']['G'])) < 1e-9
        assert abs(rows['C']['first_plan']['scores']['C'][i]-a['coverage_only_proxy']) < 1e-9
    assert rows['S']['first_plan']['scores']['S'] == rows['S_gainFrozen']['first_plan']['scores']['S']
    # First-state shared inputs imply native X is the only wrong-semantics change.
    assert rows['X']['first_plan']['scores']['S'] == rows['S']['first_plan']['scores']['S']
    out = scene_path(seed)/'selfcheck.json'
    write(out, dict(status='passed', seed=seed, simulator_actions=0,
                     checked_at_unix_s=time.time(), scope='First-state config and isolated switch checks, not trajectory outcome evidence', arms=rows))
    print(json.dumps(dict(status='passed', seed=seed, simulator_actions=0,
                          candidate_count=len(base['candidates']), output=str(out))), flush=True)


def new_attempt(seed, arm):
    root = scene_path(seed)/'runs'/arm
    root.mkdir(parents=True, exist_ok=True)
    for index in range(1, 10000):
        path = root/f'attempt_{index:03d}'
        try:
            path.mkdir()
            return path
        except FileExistsError:
            continue
    raise RuntimeError('attempt index exhausted')


def export_geometry(out, mapper, world):
    import numpy as np
    import open3d as o3d
    np.savez_compressed(out/'final_belief.npz', belief=mapper.belief,
                        camera_seen=mapper.camera_seen, position=np.asarray(world.position),
                        heading=np.asarray(world.heading))
    all_rows = list(mapper.quality.values())
    all_q = {key: np.asarray([row[key] for row in all_rows]) for key in all_rows[0]} if all_rows else {}
    q = mapper.quality_evidence(max_points=max(1, len(mapper.quality))) or {}
    np.savez_compressed(out/'quality_evidence.npz', **q)
    np.savez_compressed(out/'all_quality_evidence.npz', **all_q)
    mesh = mapper.mesh()
    mesh_path = out/'final_tsdf_mesh.ply'
    if len(mesh.vertices):
        assert o3d.io.write_triangle_mesh(str(mesh_path), mesh, write_ascii=False)
    result = dict(all_measured_patches=len(all_rows), quality_height_filtered_patches=len(q.get('point', [])),
                  quality_height_range_m=[0.12, 1.8], quality_sampling_cap_applied=False,
                  evidence_voxel_m=0.15, mesh_vertices=len(mesh.vertices), mesh_triangles=len(mesh.triangles),
                  tsdf_voxel_m=mapper.config.voxel_m, mesh_exported=mesh_path.exists(),
                  surface_accuracy_evaluated=False)
    write(out/'geometry_exports.json', result)
    return result


def run(seed, arm):
    initial = verify(seed); cfg = protocol(); out = new_attempt(seed, arm)
    started = time.monotonic(); steps = []; choices = []; timings = []
    write(out/'attempt.json', dict(status='started', arm=arm, seed=seed,
         scene_role=initial['scene_role'], started_unix_s=time.time(),
         attempt_directory=str(out), protocol_sha256=sha(HERE/'protocol.json'),
         runner_sha256=sha(__file__), prepared_freeze_sha256=sha(scene_path(seed)/'prepared/freeze.json'),
         paid_action_budget=cfg['policy']['paid_action_budget']))
    try:
        world, tr, p, comp, runtime, effective = bootstrap(seed, arm)
        assert p.sha256() == initial['initial_packet_sha256'], 'first packet differs'
        write(out/'effective_configuration.json', effective)
        mapper = runtime.states[0]['mapper']; first = evaluate_belief(mapper.belief, world.reachable)
        write(out/'initial_evaluation.json', first)
        while not runtime.states[0]['closed']:
            t = time.monotonic(); action = runtime.next_local_action(0)
            timings.append(time.monotonic()-t)
            choices = [dict(inputs=x['inputs'], outputs=x['outputs'])
                       for x in comp._cpu_backend.calls if x['method'] == 'select_topo_target']
            write(out/'choices.json', choices)
            if action is None:
                break
            raw, collision, done = world.step(action)
            p = packet(world, tr, raw, seed, action, collision, done)
            runtime.observe(0, world.step_count, None, None, None, sensor_packet=p)
            measured = evaluate_belief(mapper.belief, world.reachable)
            steps.append(dict(step=world.step_count, action=action, position=list(world.position),
                heading=world.heading, **measured, path_length_m=world.moves*world.config.resolution_m,
                collision=bool(collision), done=bool(done), packet_sha256=p.sha256(),
                measured_patch_count=len(mapper.quality),
                gain_posterior=comp._cpu_backend.scenes[0]['gain'].snapshot()['posterior_mean']))
            write(out/'steps.json', steps)
            write(out/'heartbeat.json', dict(step=world.step_count, elapsed_s=time.monotonic()-started,
                                             coverage_fraction=measured['coverage_fraction']))
        summary = runtime.sensor_episode_summary(0)
        write(out/'runtime_audit.json', runtime.audit)
        write(out/'episode_summary.json', summary)
        geometry = export_geometry(out, mapper, world)
        diagnostics = []
        for record in choices:
            output = record['outputs']; audit = output['candidate_audit']; selected = output['selected']
            diagnostics.append(dict(plan=output['plan_number'], mode=output['mode'],
                paid_before=cfg['policy']['paid_action_budget']-audit['remaining_budget'],
                remaining_budget=audit['remaining_budget'], feasible_states=audit['feasible_states'],
                candidate_count=len(output['candidates']), status=audit['status'],
                minimum_current_return_cost=audit['minimum_current_return_cost'],
                scores=output['scores'], selected_pose=None if selected is None else selected['pose'],
                selected_outbound_cost=None if selected is None else selected['outbound_cost'],
                selected_return_cost=None if selected is None else selected['return_cost']))
        write(out/'plan_diagnostics.json', diagnostics)
        gain = comp._cpu_backend.scenes[0]['gain'].snapshot()
        write(out/'final_gain_calibration.json', gain)
        final = evaluate_belief(mapper.belief, world.reachable)
        def hitting(field):
            return {str(target): 0 if first[field] >= target else next(
                    (row['step'] for row in steps if row[field] >= target), None)
                    for target in cfg['evaluation']['thresholds']}
        trace = json.dumps([(row['action'], row['position'], row['heading']) for row in steps], sort_keys=True).encode()
        unchanged = source_hashes() == json.loads((scene_path(seed)/'prepared/freeze.json').read_text())['source_sha256']
        assert unchanged, 'scientific source changed during attempt'
        result = dict(status='completed_execution', mode=arm, arm=arm, seed=seed,
            scene_id=initial['scene_id'], scene_role=initial['scene_role'], independent_layouts=1,
            topology_family='four_room_cross', paid_actions=len(steps),
            initial_coverage_fraction=first['coverage_fraction'], final_coverage_fraction=final['coverage_fraction'],
            coverage_gain_percentage_points=100*(final['coverage_fraction']-first['coverage_fraction']),
            free_correct_fraction=final['free_correct_fraction'], false_occupied_fraction=final['false_occupied_fraction'],
            per_room=final['per_room'], reference_free_cells=final['reference_free_cells'],
            path_length_m=world.moves*world.config.resolution_m,
            turn_actions=sum(row['action'] in ('left','right') for row in steps), collisions=world.collisions,
            termination=summary['termination'], initial_packet_sha256=initial['initial_packet_sha256'],
            trajectory_sha256=hashlib.sha256(trace).hexdigest(), global_planning_calls=len(choices),
            paid_action_budget=cfg['policy']['paid_action_budget'], first_coverage_action=hitting('coverage_fraction'),
            first_free_correct_action=hitting('free_correct_fraction'), decision_wall_seconds_total=sum(timings),
            elapsed_s=time.monotonic()-started, measured_patch_count=len(mapper.quality),
            reconstruction_accuracy_evaluated=False, quality_export=geometry,
            final_gain_calibration={key: value for key, value in gain.items() if key != 'events'},
            effective_args=effective['effective_args'], capabilities=comp.capabilities,
            source_hashes_unchanged=unchanged)
        write(out/'result.json', result)
        manifest = {p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file()}
        write(out/'artifact_manifest.json', dict(status='completed_execution', files_sha256=manifest))
        print(json.dumps(dict(output=str(out), **result)), flush=True)
    except BaseException as exc:
        write(out/'failure.json', dict(status='failed', error=repr(exc), traceback=traceback.format_exc(),
                                      paid_actions=len(steps), elapsed_s=time.monotonic()-started))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('prepare', 'verify', 'selfcheck', 'run'))
    parser.add_argument('--seed', required=True, type=int, choices=(20261119, 20261120, 20261121))
    parser.add_argument('--arm', choices=('C', 'G', 'S', 'X', 'G2', 'S_gainFrozen'))
    args = parser.parse_args(); dependencies()
    if args.command == 'prepare': prepare(args.seed)
    elif args.command == 'verify': print(json.dumps(verify(args.seed)))
    elif args.command == 'selfcheck': selfcheck(args.seed)
    elif args.arm is None: parser.error('run requires --arm; no implicit batch')
    else: run(args.seed, args.arm)


if __name__ == '__main__':
    main()
