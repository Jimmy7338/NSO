#!/usr/bin/env python3
"""Evaluate one completed matrix export; optional exact depth/mesh replay.

No actor is run. No automatic attempt selection or implicit batch is provided.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
SOURCE=Path('/home/ouc/nso_robot/analyses/reproduction_20261104/simulation_publication_stage/experiments/unknown_exploration_20261104/source')
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
sys.path.insert(0,str(SOURCE))
import numpy as np
import open3d as o3d
from nso.observed_runtime_mapper_v10 import ObservedRuntimeMapperV10
from exterior_reference import build_reference


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--attempt',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--verify-depth',action='store_true',help='Also replay each sensor packet and compare the final native TSDF mesh')
    a=p.parse_args();attempt=a.attempt.resolve();out=a.output.resolve()
    root=attempt.parents[4];seed=int(attempt.parents[2].name);arm=attempt.parent.name
    assert attempt.name.startswith('attempt_') and attempt.parents[1].name=='runs'
    spec=importlib.util.spec_from_file_location('matrix_sensor_helpers',root/'run.py')
    matrix=importlib.util.module_from_spec(spec);spec.loader.exec_module(matrix)
    initial=matrix.verify(seed)
    manifest=json.loads((attempt/'artifact_manifest.json').read_text())
    assert manifest['status']=='completed_execution'
    for name,wanted in manifest['files_sha256'].items():assert sha(attempt/name)==wanted,name
    result=json.loads((attempt/'result.json').read_text())
    assert result['status']=='completed_execution' and result['seed']==seed and result['arm']==arm
    source=json.loads((root/'scenes'/str(seed)/'prepared/freeze.json').read_text())['source_sha256']
    out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    code_paths=[Path(__file__),HERE/'exterior_reference.py',HERE/'protocol.json',SOURCE/'utils/reconstruction_metrics.py']
    codehash={str(x):sha(x) for x in code_paths}
    inputs=[attempt/'artifact_manifest.json',root/'protocol.json',root/'run.py',root/'scenes'/str(seed)/'prepared/freeze.json']
    inputhash={str(x):sha(x) for x in inputs}
    write(out/'attempt.json',dict(created_unix_s=time.time(),source_attempt=str(attempt),
          verify_depth_requested=a.verify_depth,evaluator_sha256=codehash,input_receipt_sha256=inputhash))
    try:
        world,tr,packet=matrix.world_and_packet(seed)
        assert packet.sha256()==initial['initial_packet_sha256']==result['initial_packet_sha256']
        mesh=o3d.io.read_triangle_mesh(str(attempt/'final_tsdf_mesh.ply'))
        exports=json.loads((attempt/'geometry_exports.json').read_text())
        assert len(mesh.triangles)==exports['mesh_triangles'] and len(mesh.vertices)==exports['mesh_vertices']
        replay_info=dict(performed=False,mesh_provenance='Hash-verified native TSDF export from unchanged mapper; not re-rendered in this evaluator call')
        if a.verify_depth:
            mapper=ObservedRuntimeMapperV10(world.shape,world.config);mapper.update(packet.frame,packet.scan)
            steps=json.loads((attempt/'steps.json').read_text())
            for row in steps:
                raw,col,done=world.step(row['action']);packet=matrix.packet(world,tr,raw,seed,row['action'],col,done)
                assert packet.sha256()==row['packet_sha256'],row['step']
                mapper.update(packet.frame,packet.scan)
                coverage=float(np.count_nonzero((mapper.belief!=-1)&world.reachable)/world.reachable.sum())
                assert coverage==row['coverage_fraction'],row['step']
            replay=mapper.mesh()
            assert np.array_equal(np.asarray(mesh.triangles),np.asarray(replay.triangles)),'replayed mesh topology differs'
            assert np.allclose(np.asarray(mesh.vertices),np.asarray(replay.vertices),atol=1e-10,rtol=0),'replayed vertices differ'
            assert len(mapper.quality)==result['measured_patch_count']
            replay_info=dict(performed=True,verified_packets=len(steps)+1,
                every_frame_coverage_identical=True,exported_mesh_identical_to_replayed_depth_tsdf=True,
                elapsed_s=time.monotonic()-start)
        evaluator,exterior,classes,info=build_reference(world)
        metrics=evaluator.evaluate(mesh,result['final_coverage_fraction'],thresholds=(.05,.10))
        reconstruction=o3d.t.geometry.RaycastingScene(nthreads=1)
        reconstruction.add_triangles(o3d.t.geometry.TriangleMesh.from_legacy(mesh))
        distances=reconstruction.compute_distance(o3d.core.Tensor(evaluator.reference),nthreads=1).numpy()
        metrics.update(completeness_error_mean_m=float(distances.mean()),
                       completeness_error_p95_m=float(np.percentile(distances,95)))
        np.savez_compressed(out/'fixed_reference.npz',points=evaluator.reference,classes=evaluator.classes)
        reference_hash=hashlib.sha256(evaluator.reference.tobytes()+evaluator.classes.tobytes()).hexdigest()
        assert matrix.source_hashes()==source
        assert codehash=={x:sha(x) for x in codehash}
        assert inputhash=={x:sha(x) for x in inputhash}
        for name,wanted in manifest['files_sha256'].items():assert sha(attempt/name)==wanted,name
        value=dict(status='complete_matrix_surface_evaluation',seed=seed,arm=arm,
            scene_id=result['scene_id'],scene_role=result['scene_role'],source_attempt=str(attempt),
            paid_actions=result['paid_actions'],final_coverage_fraction=result['final_coverage_fraction'],
            metrics=metrics,reference=info,reference_points_and_classes_sha256=reference_hash,
            sensor_replay=replay_info,export_manifest_fully_verified=True,source_hashes_unchanged=True,
            no_actor_executed=True,no_robot_or_ros=True,evaluator_sha256=codehash,
            source_receipts_sha256=inputhash,source_mesh_sha256=sha(attempt/'final_tsdf_mesh.ply'),
            reference_npz_sha256=sha(out/'fixed_reference.npz'),elapsed_s=time.monotonic()-start,
            metric_protocol=str(HERE/'protocol.json'),
            limitation='Synthetic constructed scene with exact pose and ideal visible labels; shared topology and class-specific outcomes do not provide additional independent scenes.')
        write(out/'result.json',value)
        print(json.dumps(dict(seed=seed,arm=arm,output=str(out),metrics=metrics,elapsed_s=value['elapsed_s'])),flush=True)
    except BaseException as exc:
        write(out/'failure.json',dict(error=repr(exc),traceback=traceback.format_exc(),elapsed_s=time.monotonic()-start))
        raise


if __name__=='__main__':main()
