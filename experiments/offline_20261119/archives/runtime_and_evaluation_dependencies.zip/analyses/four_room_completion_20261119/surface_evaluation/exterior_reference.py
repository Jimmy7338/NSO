"""Evaluator-only exact exterior of the simulator's axis-aligned box union.

This is not a policy input. No reconstruction or tested trajectory selects the
surface reference. Areas covered by another solid and duplicated coplanar
faces are removed by partitioning each source face at intersecting box edges.
"""
import numpy as np
import open3d as o3d
from utils.reconstruction_metrics import ReconstructionEvaluator, ray_scene


def extract_boxes(world):
    vertices = np.asarray(world.mesh.vertices)
    triangles = np.asarray(world.mesh.triangles)
    assert len(vertices) % 8 == 0 and len(triangles) == len(vertices)//8*12
    lows, highs, labels = [], [], []
    for i in range(len(vertices)//8):
        v = vertices[i*8:(i+1)*8]
        lo, hi = v.min(0), v.max(0)
        assert np.all(hi>lo)
        assert len(np.unique(v,axis=0))==8
        assert np.all(np.isclose(v,lo[None,:],atol=1e-10)|np.isclose(v,hi[None,:],atol=1e-10))
        assert np.all((triangles[i*12:(i+1)*12]>=i*8)&(triangles[i*12:(i+1)*12]<(i+1)*8))
        lab=np.asarray(world.triangle_classes)[i*12:(i+1)*12]
        assert len(np.unique(lab))==1
        lows.append(lo); highs.append(hi); labels.append(int(lab[0]))
    return np.asarray(lows),np.asarray(highs),np.asarray(labels)


def exterior_union(lows, highs, labels):
    lows,highs=np.asarray(lows,float),np.asarray(highs,float)
    eps=1e-7
    vertices,triangles,outlabels=[],[],[]
    for i,(lo,hi,lab) in enumerate(zip(lows,highs,labels)):
        for axis in range(3):
            u,v=[a for a in range(3) if a!=axis]
            for side in (-1,1):
                plane=lo[axis] if side<0 else hi[axis]
                intersect=((lows[:,axis]<=plane+eps)&(highs[:,axis]>=plane-eps)&
                           (highs[:,u]>lo[u]+eps)&(lows[:,u]<hi[u]-eps)&
                           (highs[:,v]>lo[v]+eps)&(lows[:,v]<hi[v]-eps))
                ids=np.flatnonzero(intersect)
                us=np.unique(np.r_[lo[u],hi[u],np.clip(lows[ids,u],lo[u],hi[u]),np.clip(highs[ids,u],lo[u],hi[u])])
                vs=np.unique(np.r_[lo[v],hi[v],np.clip(lows[ids,v],lo[v],hi[v]),np.clip(highs[ids,v],lo[v],hi[v])])
                for u0,u1 in zip(us[:-1],us[1:]):
                    for v0,v1 in zip(vs[:-1],vs[1:]):
                        if min(u1-u0,v1-v0)<eps:continue
                        p=np.zeros(3);p[axis]=plane;p[u]=(u0+u1)/2;p[v]=(v0+v1)/2
                        outside=p.copy();outside[axis]+=side*eps*10
                        if np.any(np.all((outside>lows+eps)&(outside<highs-eps),axis=1)):
                            continue
                        # Select one owner for coincident, externally visible faces.
                        same=np.abs((lows[:,axis] if side<0 else highs[:,axis])-plane)<eps
                        covers=(lows[:,u]<p[u])&(highs[:,u]>p[u])&(lows[:,v]<p[v])&(highs[:,v]>p[v])
                        if np.flatnonzero(same&covers).min()!=i:continue
                        corners=[]
                        for a,b in ((u0,v0),(u1,v0),(u1,v1),(u0,v1)):
                            q=p.copy();q[u]=a;q[v]=b;corners.append(q)
                        base=len(vertices);vertices.extend(corners)
                        cross=np.cross(corners[1]-corners[0],corners[2]-corners[0])
                        faces=((0,1,2),(0,2,3)) if cross[axis]*side>0 else ((0,2,1),(0,3,2))
                        triangles.extend([[base+x for x in face] for face in faces]);outlabels.extend([int(lab)]*2)
    mesh=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(np.asarray(vertices)),
                                 o3d.utility.Vector3iVector(np.asarray(triangles,dtype=np.int32)))
    mesh.compute_triangle_normals()
    return mesh,np.asarray(outlabels,int)


def selfcheck():
    cases=[('single',[[0,0,0]],[[1,1,1]],6.),
           ('identical',[[0,0,0],[0,0,0]],[[1,1,1],[1,1,1]],6.),
           ('touching',[[0,0,0],[1,0,0]],[[1,1,1],[2,1,1]],10.),
           ('overlap',[[0,0,0],[.5,0,0]],[[1,1,1],[1.5,1,1]],8.),
           ('nested',[[0,0,0],[.5,.5,.5]],[[2,2,2],[1.5,1.5,1.5]],24.)]
    results=[]
    for name,lo,hi,expected in cases:
        mesh,_=exterior_union(lo,hi,[1]*len(lo))
        area=mesh.get_surface_area()
        assert np.isclose(area,expected,atol=1e-9),(name,area,expected)
        results.append(dict(name=name,area_m2=area,expected_area_m2=expected))
    return results


def first_hit_check(raw_mesh, exterior, world):
    old,new=ray_scene(raw_mesh),ray_scene(exterior)
    c=world.config
    lo,hi,_=extract_boxes(world)
    checks=[]
    for offset in (0.,np.pi/64):
        rays=[]
        for r,col in np.argwhere(world.reachable):
            if r%4 or col%4:continue
            origin=[(col+.5)*c.resolution_m,(world.shape[0]-r-.5)*c.resolution_m,c.camera_height_m]
            for angle in np.linspace(-np.pi,np.pi,64,endpoint=False)+offset:
                for slope in (-.6,0.,.6):
                    rays.append([*origin,np.cos(angle),np.sin(angle),slope])
        rays=np.asarray(rays,np.float32)
        a=old.cast_rays(o3d.core.Tensor(rays),nthreads=1)['t_hit'].numpy()
        b=new.cast_rays(o3d.core.Tensor(rays),nthreads=1)['t_hit'].numpy()
        valid=np.isfinite(a)&np.isfinite(b)
        errors=np.zeros(len(a));errors[valid]=np.abs(a[valid]-b[valid])
        mismatch=(np.isfinite(a)!=np.isfinite(b))|(errors>1e-4)
        singular=[]
        for index in np.flatnonzero(mismatch):
            # A ray exactly in an axis-aligned face plane is an edge-contact
            # case: triangle subdivision changes zero-measure hit ownership.
            tangent=any(abs(rays[index,axis+3])<1e-7 and
                        np.any(np.abs(np.r_[lo[:,axis],hi[:,axis]]-rays[index,axis])<1e-6)
                        for axis in range(3))
            assert tangent and offset==0., ('non-tangential first-hit mismatch',int(index))
            singular.append(dict(index=int(index),ray=rays[index].tolist(),
                raw_t=None if not np.isfinite(a[index]) else float(a[index]),
                exterior_t=None if not np.isfinite(b[index]) else float(b[index])))
        checked=valid&~mismatch
        checks.append(dict(azimuth_offset_rad=offset,rays=len(a),
            non_tangent_max_depth_difference_m=float(errors[checked].max()),
            tangent_edge_contact_disagreements=singular,
            all_non_tangent_rays_match=True))
    return checks


def build_reference(world, count=100000, seed=20261119):
    lows,highs,labels=extract_boxes(world)
    mesh,classes=exterior_union(lows,highs,labels)
    proxy=type('EvaluatorTruthOnly',(),dict(mesh=mesh,triangle_classes=classes,
               config=world.config,shape=world.shape,reachable=world.reachable))()
    evaluator=ReconstructionEvaluator(proxy,count=count,seed=seed)
    info=dict(reference_definition='Area-sampled exact box-union exterior visible from fixed reachable 0.8m lattice at camera height with arbitrary yaw; first-hit visibility; independent of trajectory',
              source_boxes=len(lows),raw_mesh_triangles=len(world.mesh.triangles),
              exterior_mesh_triangles=len(mesh.triangles),raw_mesh_area_m2=world.mesh.get_surface_area(),
              exterior_mesh_area_m2=mesh.get_surface_area(),area_samples_drawn=count,
              reference_samples=len(evaluator.reference),
              reference_classes={str(k):int(np.count_nonzero(evaluator.classes==k)) for k in np.unique(evaluator.classes)},
              selfchecks=selfcheck(),first_hit_equivalence=first_hit_check(world.mesh,mesh,world))
    return evaluator,mesh,classes,info
