#!/usr/bin/env python3
"""Independent shared-instance frontend study; no implicit batch or hardware."""
import argparse,copy,hashlib,importlib.util,inspect,json,os,shutil,signal,time,traceback
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
BASE=ROOT/'exploration_study/run.py'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
r=load('frozen_exploration_outer_library',BASE)
write=r.write;sha=r.sha
LIVE=Path('/home/ouc/nso_robot/workspaces/nso_hybrid_20261029/nso_bridge/nso_bridge')
MODULES=[LIVE/'instance_support.py',LIVE/'instance_asset_adapter.py']
installed=False

def protocol():return json.loads((HERE/'protocol.json').read_text())
def alias_arm(a):return 'S_no_semantics' if a=='S0' else a

def install():
 global installed,isp,iap,original,rf,v8,v81
 if installed:return
 r.dependencies()
 import nso.response_features_v7 as rf
 import nso.competition_candidates_v8 as v8
 import nso.competition_candidates_v8_1 as v81
 for m in [rf,v8,v81]:assert Path(m.__file__).resolve().is_relative_to(r.SOURCE.resolve())
 original=rf.observed_patches
 assert v8.observed_patches is original and v81.observed_patches is original
 isp=load('fixed_live_instance_support',MODULES[0]);iap=load('fixed_live_instance_asset_adapter',MODULES[1])
 def dispatch(mapper,config=rf.ResponseFeatureConfig()):
  if getattr(mapper,'asset_grouping_profile',None)=='measured_instance_support_v1':
   return iap.observed_instance_patches(mapper,config,original)
  return original(mapper,config)
 for m in [rf,v8,v81]:m.observed_patches=dispatch
 installed=True

def binding_identity():
 install()
 f={'original_observed_patches':original,'observed_instance_patches':iap.observed_instance_patches,'instance_observe':isp.InstanceSupportIndex.observe}
 return dict(source_sha256={str(p):sha(p)for p in MODULES},function_source_sha256={k:hashlib.sha256(inspect.getsource(v).encode()).hexdigest()for k,v in f.items()},
  original_source_module=str(Path(inspect.getfile(original)).resolve()),alias_modules=[str(Path(m.__file__).resolve())for m in [rf,v8,v81]])

def owner(raw):
 import numpy as np
 result=np.zeros(raw.semantic.shape,np.int64)
 result[raw.semantic==2]=1;result[raw.semantic==3]=2
 assert not result[raw.depth_m==0].any()
 return result

def associate(mapper,raw,frame_id):
 import numpy as np
 o=owner(raw);event=mapper.instance_support_index.observe(raw,o,frame_id)
 return dict(frame_id=frame_id,timestamp_s=float(raw.timestamp_s),owner_sha256=hashlib.sha256(o.tobytes()).hexdigest(),
  owner_counts={str(k):int((o==k).sum())for k in [0,1,2]},association=event,
  index_state={k:v for k,v in mapper.instance_support_index.summary().items()if k!='observations'})

def bootstrap(arm,shared=None):
 import numpy as np
 install()
 world,tr,p,comp,runtime,audit=r.bootstrap(alias_arm(arm),shared)
 mapper=runtime.states[0]['mapper'];state=comp._cpu_backend.scenes[0]
 before=(mapper.frames,state['ledger'].remaining_budget,copy.deepcopy(state['gain'].snapshot()),mapper.belief.copy())
 mapper.instance_support_index=isp.InstanceSupportIndex();mapper.asset_grouping_profile='measured_instance_support_v1'
 raw=world.sense();receipt=associate(mapper,raw,p.frame_id)
 # Initialize the added representation before first decision; no observation
 # is replayed and neither IGCR nor action accounting is touched.
 state['planning_direction_support']=None
 comp._cpu_backend.update_semantic(0)
 assert state['planning_direction_support']==state['current_direction_support']
 assert mapper.frames==before[0] and state['ledger'].remaining_budget==before[1]
 assert state['gain'].snapshot()==before[2] and np.array_equal(mapper.belief,before[3])
 audit.update(arm=arm,frontend_variant='partial_ideal_measured_instance_support_v1',
  original_method_equivalence=False,G_is_pure_no_semantics=False,shared_instance_masks=True,
  partial_ideal_instance_support=True,natural_detector=False,initial_owner_receipt=receipt)
 return world,tr,p,comp,runtime,audit,receipt

def verify():
 install();baseline=r.verify();f=json.loads((HERE/'prepared/freeze.json').read_text())
 assert sha(__file__)==f['runner_sha256'] and sha(HERE/'protocol.json')==f['protocol_sha256']
 assert sha(BASE)==f['baseline_runner_sha256'] and sha(r.HERE/'prepared/freeze.json')==f['baseline_freeze_sha256']
 assert binding_identity()==f['binding_identity']
 for name,h in f['prepared_files_sha256'].items():assert sha(HERE/'prepared'/name)==h
 # World, all assets, source, topology cache and libraries also verified by r.verify.
 return json.loads((HERE/'prepared/initial_state.json').read_text())

def prepare():
 import numpy as np
 install();initial=r.verify();out=HERE/'prepared';out.mkdir(exist_ok=False)
 world,tr,p=r.world_and_packet('G');assert p.sha256()==initial['initial_packet_sha256']
 np.save(out/'initial_owner.npy',owner(p.frame),allow_pickle=False)
 for name in ['initial_sensor.npz','initial_frame.npz','initial_scan.npz','evaluator_truth.npz']:
  shutil.copyfile(r.HERE/'prepared'/name,out/name)
 initial=copy.deepcopy(initial);initial['initial_packet_sha256_by_arm']={a:initial['initial_packet_sha256_by_arm'][alias_arm(a)]for a in protocol()['arms']}
 initial.update(frontend_variant='partial_ideal_measured_instance_support_v1',original_method_equivalence=False,
  initial_owner_sha256=hashlib.sha256(owner(p.frame).tobytes()).hexdigest(),
  identical_initial_sensor_and_geometry_to_original=True)
 write(out/'initial_state.json',initial)
 write(out/'freeze.json',dict(runner_sha256=sha(__file__),protocol_sha256=sha(HERE/'protocol.json'),
  baseline_runner_sha256=sha(BASE),baseline_freeze_sha256=sha(r.HERE/'prepared/freeze.json'),
  binding_identity=binding_identity(),prepared_files_sha256={p.name:sha(p)for p in out.iterdir()if p.is_file()},created_unix_s=time.time()))
 verify();print(json.dumps(dict(status='prepared',owner_sha256=initial['initial_owner_sha256'])),flush=True)

def selfcheck():
 import numpy as np
 from nso.cpu_sensor_contract_v10 import digest
 initial=verify();shared=r.world_and_packet('G');rows={};sigs=[]
 for arm in protocol()['arms']:
  world,tr,p,comp,runtime,effective,receipt=bootstrap(arm,shared)
  assert p.sha256()==initial['initial_packet_sha256_by_arm'][arm]
  assert r.nonsemantic_packet_sha(p)==initial['nonsemantic_initial_packet_sha256']
  assert receipt['owner_sha256']==initial['initial_owner_sha256']
  comp._cpu_backend.select_target(0);state=comp._cpu_backend.scenes[0];plan=state['last_selection']
  assert world.step_count==0
  sig=(digest(plan['candidates']),digest(state['mapper'].belief));sigs.append(sig)
  rows[arm]=dict(effective=effective,owner_receipt=receipt,candidate_sha256=sig[0],belief_sha256=sig[1],
   first_plan=plan,mechanism=r.mechanism_probe(state,p,plan),
   measured_instance_assets=[{k:a[k]for k in ['group','instance_track_id','marked_points','class_vote','support_points']}for a in state['assets']],paid_actions=0)
 assert len(set(sigs))==1,'paired initial candidate/geometry mismatch'
 np.testing.assert_allclose(rows['S0']['first_plan']['scores']['S'],rows['G']['first_plan']['scores']['G'],rtol=0,atol=1e-10)
 assert rows['X']['first_plan']['scores']['S']==rows['S']['first_plan']['scores']['S']
 verify();write(HERE/'selfcheck.json',dict(status='passed',simulator_actions=0,initial_candidates_identical_all_arms=True,
  initial_owner_identical_all_arms=True,S0_equals_G=True,original_initial_sensor_and_geometry_preserved=True,arms=rows))
 print(json.dumps(dict(status='passed',arms=list(rows),paid_actions=0,candidates=len(rows['G']['first_plan']['candidates']),
  marked_assets=len([a for a in rows['G']['measured_instance_assets']if a['marked_points']]))),flush=True)

def attempt_dir(arm):
 p=HERE/'runs'/arm;p.mkdir(parents=True,exist_ok=True)
 for i in range(1,10000):
  try:a=p/f'attempt_{i:03d}';a.mkdir();return a
  except FileExistsError:pass
 raise RuntimeError('attempts exhausted')

def run(arm):
 import numpy as np
 initial=verify();cfg=protocol();out=attempt_dir(arm);start=time.monotonic();steps=[];owners=[];timings=[];mapper=world=runtime=None
 write(out/'attempt.json',dict(status='started',arm=arm,frontend_variant=cfg['instance_frontend']['version'],
  original_method_equivalence=False,protocol_sha256=sha(HERE/'protocol.json'),runner_sha256=sha(__file__),
  prepared_freeze_sha256=sha(HERE/'prepared/freeze.json'),paid_action_budget=256,started_unix_s=time.time()))
 def interrupted(signum,frame):raise InterruptedError(f'external signal {signum}; not an algorithmic outcome')
 signal.signal(signal.SIGTERM,interrupted)
 try:
  world,tr,p,comp,runtime,effective,first_owner=bootstrap(arm);owners.append(first_owner)
  mapper=runtime.states[0]['mapper'];state=comp._cpu_backend.scenes[0]
  assert p.sha256()==initial['initial_packet_sha256_by_arm'][arm]
  assert first_owner['owner_sha256']==initial['initial_owner_sha256']
  write(out/'effective_configuration.json',effective);write(out/'owner_receipts.json',owners);first=r.evaluate(mapper.belief,world.reachable);write(out/'initial_evaluation.json',first)
  streak=0;choices=[]
  while not runtime.states[0]['closed']:
   t=time.monotonic();action=runtime.next_local_action(0);decision=time.monotonic()-t;timings.append(decision)
   choices=[dict(inputs=x['inputs'],outputs=x['outputs'],call_metadata={k:v for k,v in x.items()if k not in ['inputs','outputs']})for x in comp._cpu_backend.calls if x['method']=='select_topo_target']
   write(out/'choices.json',choices);write(out/'runtime_audit.json',runtime.audit)
   if action is None:break
   active=runtime.states[0]['option'];phase=runtime.states[0]['phase'];target=None if active is None else list(active['pose']);option=None if active is None else active['option_id']
   known_before=(mapper.belief!=-1).copy();t=time.monotonic();raw,col,done=world.step(action)
   p=r.packet(world,tr,raw,action,col,done,arm=alias_arm(arm));sensor_time=time.monotonic()-t
   # Packet validates before support mutation; original runtime owns the sole fusion.
   t=time.monotonic();orec=associate(mapper,raw,p.frame_id);owners.append(orec)
   runtime.observe(0,world.step_count,None,None,None,sensor_packet=p);observe_time=time.monotonic()-t
   measured=r.evaluate(mapper.belief,world.reachable);newly_known=int(np.count_nonzero((mapper.belief!=-1)&~known_before&world.reachable));streak=streak+1 if newly_known==0 else 0
   steps.append(dict(step=world.step_count,action=action,position=list(world.position),heading=world.heading,**measured,
    new_reference_known_cells=newly_known,zero_coverage_gain_streak=streak,path_length_m=world.moves*world.config.resolution_m,
    collision=bool(col),done=bool(done),packet_sha256=p.sha256(),nonsemantic_packet_sha256=r.nonsemantic_packet_sha(p),
    owner_sha256=orec['owner_sha256'],owner_counts=orec['owner_counts'],instance_index_state=orec['index_state'],
    active_option_id=option,selected_target_pose=target,phase_before_action=phase,
    matched_target_pose_after_step=target==[*world.position,world.heading]if target is not None else None,
    decision_wall_s=decision,sensor_wall_s=sensor_time,observe_wall_s=observe_time,
    partial_semantic_pixels={str(c):int((p.frame.semantic==c).sum())for c in [0,2,3]},
    measured_patch_count=len(mapper.quality),gain_posterior=state['gain'].snapshot()['posterior_mean'],
    measured_asset_count=len(state['assets']),marked_asset_count=sum(a['marked_points']>0 for a in state['assets'])))
   write(out/'steps.json',steps);write(out/'owner_receipts.json',owners);write(out/'heartbeat.json',dict(step=world.step_count,elapsed_s=time.monotonic()-start,coverage_fraction=measured['coverage_fraction']))
  summary=runtime.sensor_episode_summary(0);write(out/'episode_summary.json',summary);write(out/'runtime_audit.json',runtime.audit)
  geometry=r.base.export_geometry(out,mapper,world);write(out/'final_gain_calibration.json',state['gain'].snapshot());write(out/'final_instance_index.json',mapper.instance_support_index.summary())
  final=r.evaluate(mapper.belief,world.reachable)
  def hits(field):return {str(x):0 if first[field]>=x else next((a['step']for a in steps if a[field]>=x),None)for x in cfg['evaluation']['thresholds']}
  verify();trace=json.dumps([(a['action'],a['position'],a['heading'])for a in steps],sort_keys=True).encode()
  result=dict(status='completed_execution',arm=arm,scene_id=initial['scene_id'],scene_role=initial['scene_role'],
   independent_layouts=1,frontend_variant=cfg['instance_frontend']['version'],original_method_equivalence=False,
   partial_ideal_instance_support=True,shared_instance_frontend_G_S_S0=True,G_is_pure_no_semantics=False,
   paid_actions=len(steps),paid_action_budget=256,initial_coverage_fraction=first['coverage_fraction'],final_coverage_fraction=final['coverage_fraction'],
   final_evaluation=final,free_correct_fraction=final['free_correct_fraction'],false_occupied_fraction=final['false_occupied_fraction'],reference_free_cells=final['reference_free_cells'],
   first_coverage_action=hits('coverage_fraction'),first_free_correct_action=hits('free_correct_fraction'),path_length_m=world.moves*world.config.resolution_m,
   turn_actions=sum(a['action']in['left','right']for a in steps),collisions=world.collisions,termination=summary['termination'],
   final_pose=[*world.position,world.heading],final_pose_equals_initial_anchor=[*world.position,world.heading]==initial['anchor'],
   zero_gain_actions=sum(a['new_reference_known_cells']==0 for a in steps),longest_zero_gain_streak=max((a['zero_coverage_gain_streak']for a in steps),default=0),
   target_pose_matches=sum(a['matched_target_pose_after_step']is True for a in steps),initial_packet_sha256=initial['initial_packet_sha256_by_arm'][arm],
   nonsemantic_initial_packet_sha256=initial['nonsemantic_initial_packet_sha256'],initial_owner_sha256=first_owner['owner_sha256'],
   trajectory_sha256=hashlib.sha256(trace).hexdigest(),global_planning_calls=len(choices),decision_wall_s_total=sum(timings),elapsed_s=time.monotonic()-start,
   quality_export=geometry,reconstruction_accuracy_evaluated=False,partial_oracle_semantics=arm!='S0',semantic_labels_absent=arm=='S0',natural_detector=False,
   measured_patch_count=len(mapper.quality),effective_args=effective['effective_args'],source_and_adapter_hashes_unchanged=True)
  write(out/'result.json',result);write(out/'artifact_manifest.json',dict(status='completed_execution',files_sha256={p.name:sha(p)for p in out.iterdir()if p.is_file()}))
  print(json.dumps(dict(output=str(out),**result)),flush=True)
 except BaseException as e:
  write(out/'failure.json',dict(status='interrupted'if isinstance(e,(InterruptedError,KeyboardInterrupt))else'failed',error=repr(e),traceback=traceback.format_exc(),paid_actions=len(steps),elapsed_s=time.monotonic()-start,completed_episode=False))
  if runtime is not None:write(out/'runtime_audit.json',runtime.audit)
  if mapper is not None:
   try:
    partial=out/'partial_geometry';partial.mkdir();r.base.export_geometry(partial,mapper,world);write(partial/'PARTIAL_ONLY.json',dict(completed_episode=False,paid_actions=len(steps)))
   except Exception as x:write(out/'partial_export_failure.json',dict(error=repr(x)))
  raise

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['prepare','verify','selfcheck','run']);p.add_argument('--arm',choices=list(protocol()['arms']));a=p.parse_args();install()
 if a.command=='prepare':prepare()
 elif a.command=='verify':print(json.dumps(verify()))
 elif a.command=='selfcheck':selfcheck()
 elif a.arm is None:p.error('run requires explicit --arm; no implicit batch')
 else:run(a.arm)
if __name__=='__main__':main()
