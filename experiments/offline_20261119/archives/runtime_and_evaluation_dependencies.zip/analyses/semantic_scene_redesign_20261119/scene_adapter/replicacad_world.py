"""Static official ReplicaCAD apt_0 sensor/motion adapter; never a policy.

Only sense()/scan()/step() products may enter the actor. Geometry, collision
truth and reachable masks are simulator/evaluator-only. No ROS or hardware IO.
"""
from collections import deque
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import sys
import time
import numpy as np
import open3d as o3d
import trimesh
import shapely
from shapely.geometry import Point, LineString, Polygon, box
from shapely.strtree import STRtree

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
SOURCE = Path('/home/ouc/nso_robot/analyses/reproduction_20261104/simulation_publication_stage/experiments/unknown_exploration_20261104/source')
for directory in (SOURCE, BASE/'assets', BASE/'assets/replicacad'):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))
from env.virtual3d import VirtualConfig, camera_pose
from utils.grid_geometry import DIRECTIONS
from utils.rgbd_contract import RGBDFrame, PlanarScan
from assemble_apt0 import build
from textured_raycast import TexturedRayRenderer

SEMANTIC_REFERENCE = BASE/'exploration_evaluation/structural_reference_low.json'
ANCHOR_PROTOCOL = HERE/'horizontal_living/PROTOCOL.json'
CACHE = HERE/'precomputed_assets'
COLLISION_BAND_M = (.15, 1.2)
FLOOR_BAND_M = (-.03, .06)
FLOOR_NORMAL_MIN = .995
GEOMETRY_VERSION = 'mesh_triangle_clip_exact_xy_capsule_v1'


@dataclass(frozen=True)
class ReplicaCADConfig(VirtualConfig):
    camera_height_m: float = 1.2
    width_px: int = 120
    height_px: int = 90
    max_depth_m: float = 8.
    depth_sigma_m: float = 0.
    dropout: float = 0.
    max_steps: int = 256
    truncation_m: float = .12


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _clip_halfspace(poly, height, above):
    """Sutherland-Hodgman clip of one 3-D triangle/polygon by horizontal plane."""
    if not len(poly):
        return np.empty((0, 3))
    result = []
    previous = poly[-1]
    prev_inside = (previous[2] >= height) if above else (previous[2] <= height)
    for current in poly:
        inside = (current[2] >= height) if above else (current[2] <= height)
        if inside != prev_inside:
            t = (height - previous[2]) / (current[2] - previous[2])
            result.append(previous + t * (current - previous))
        if inside:
            result.append(current)
        previous, prev_inside = current, inside
    return np.asarray(result).reshape((-1, 3))


def _project_polygon(points):
    """Keep vertical triangles as lines; dropping degenerate XY area loses walls."""
    xy = np.unique(np.asarray(points)[:, :2], axis=0)
    if len(xy) == 1:
        return Point(xy[0])
    if len(xy) == 2:
        return LineString(xy)
    # Clipped triangle is convex, but np.unique sorted its boundary vertices.
    return shapely.convex_hull(shapely.MultiPoint(xy))


class MeshMotionGeometry:
    """Full circle/capsule clearance against height-clipped actual triangles.

    Obstacle STRtree stores exact projected clipped triangles, not object AABBs.
    Floor is the union of near-ground horizontal mesh triangle projections.
    A centre or centreline must be within that union and at least radius away
    from every floor boundary; this proves the entire circle/sweep is supported.
    """
    def __init__(self, source_scene, world_from_source):
        obstacle_parts, floor_parts = [], []
        counts = dict(source_triangles=0, clipped_obstacle_parts=0, floor_triangles=0)
        lo, hi = COLLISION_BAND_M
        flo, fhi = FLOOR_BAND_M
        for node in source_scene.graph.nodes_geometry:
            local, name = source_scene.graph[node]
            mesh = source_scene.geometry[name]
            vertices = trimesh.transform_points(mesh.vertices, world_from_source @ local)
            triangles = vertices[np.asarray(mesh.faces)]
            counts['source_triangles'] += len(triangles)
            mins, maxs = triangles[:, :, 2].min(1), triangles[:, :, 2].max(1)
            for triangle in triangles[(maxs >= lo) & (mins <= hi)]:
                poly = _clip_halfspace(_clip_halfspace(triangle, lo, True), hi, False)
                if len(poly):
                    shape = _project_polygon(poly)
                    if not shape.is_empty:
                        obstacle_parts.append(shape)
            floor_candidates = triangles[(mins >= flo) & (maxs <= fhi)]
            if len(floor_candidates):
                normals = np.cross(floor_candidates[:, 1]-floor_candidates[:, 0],
                                   floor_candidates[:, 2]-floor_candidates[:, 0])
                length = np.linalg.norm(normals, axis=1)
                select = np.abs(normals[:, 2]) >= FLOOR_NORMAL_MIN*np.maximum(length, 1e-15)
                for triangle in floor_candidates[select & (length > 1e-12)]:
                    poly = Polygon(triangle[:, :2])
                    if poly.area > 1e-12:
                        floor_parts.append(poly)
        if not obstacle_parts or not floor_parts:
            raise RuntimeError('Source geometry has no obstacle or floor triangles')
        self.obstacles = np.asarray(obstacle_parts, dtype=object)
        self.tree = STRtree(self.obstacles)
        self.floor = shapely.union_all(floor_parts)
        self.floor_boundary = self.floor.boundary
        counts.update(clipped_obstacle_parts=len(obstacle_parts), floor_triangles=len(floor_parts),
                      floor_projected_area_m2=float(self.floor.area))
        self.stats = counts

    def clearance(self, start_xy, end_xy=None):
        line = Point(start_xy) if end_xy is None else LineString([start_xy, end_xy])
        floor_covered = bool(self.floor.covers(line))
        floor_clearance = float(line.distance(self.floor_boundary)) if floor_covered else 0.
        return line, floor_covered, floor_clearance

    def valid(self, start_xy, end_xy=None, radius=.2):
        line, supported, clearance = self.clearance(start_xy, end_xy)
        if not supported or clearance < radius - 1e-9:
            return False
        xmin, ymin, xmax, ymax = line.bounds
        indices = self.tree.query(box(xmin-radius, ymin-radius, xmax+radius, ymax+radius))
        if len(indices) and np.any(shapely.distance(self.obstacles[indices], line) <= radius + 1e-9):
            return False
        return True


class ReplicaCADWorld:
    """VirtualWorld-compatible simulator, never pass this object to the policy."""
    def __init__(self, config=None, seed=20261119):
        self.config = config or ReplicaCADConfig()
        c = self.config
        if not np.isclose(c.resolution_m, .2) or not np.isclose(c.robot_radius_m, .2):
            raise ValueError('Declared apt_0 protocol requires .2m grid and .2m circle radius')
        self.seed = int(seed)
        protocol = json.loads(ANCHOR_PROTOCOL.read_text())
        self.world_from_source = np.asarray(protocol['world_from_source'], float)
        self.source_from_world = np.linalg.inv(self.world_from_source)
        self.shape = tuple(protocol['map_shape'])
        self.height, self.width = np.asarray(self.shape) * c.resolution_m
        self.start = tuple(protocol['position'])
        self.position = self.start
        self.heading = int(protocol['heading'])
        self.step_count = self.collisions = self.moves = 0
        start_time = time.monotonic()
        self._source_scene, self._records, self._node_meta = build()
        self._renderer = TexturedRayRenderer(self._source_scene)
        self._ray = self._renderer.scene  # Source (Y-up) coordinates, not actor-accessible.
        self._geometry = MeshMotionGeometry(self._source_scene, self.world_from_source)
        self._node_for_gid = {x['geometry_id']: x['node'] for x in self._renderer.stats}
        self._open_gids = [gid for gid, node in self._node_for_gid.items()
                           if self._node_meta[node]['instance_id'] == 31]
        reference = json.loads(SEMANTIC_REFERENCE.read_text())
        self._closed_regions = []
        for item in reference['node_whitelist_with_source_bounds']:
            gid = [g for g, n in self._node_for_gid.items() if n == item['node']]
            if len(gid) != 1:
                raise ValueError('Verified closed-front node missing or duplicated')
            self._closed_regions.append((gid[0], np.asarray(item['source_xyz_min_m']),
                                          np.asarray(item['source_xyz_max_m'])))
        self._build_evaluator_topology()
        if not self._robot_valid[self.start]:
            raise ValueError(f'Declared start {self.start} fails actual mesh footprint/support; do not silently move it')
        self._reachable = self._flood(self.start)
        f = c.width_px/(2*np.tan(np.deg2rad(c.fov_deg/2)))
        self.intrinsic = np.array([[f,0,(c.width_px-1)/2], [0,f,(c.height_px-1)/2], [0,0,1.]])
        self._frame_cache = {}
        self.geometry_receipt = dict(self._geometry.stats, topology_cache_key=self._topology_key,
            world_from_source=self.world_from_source.tolist(), shape=list(self.shape),
            start=list(self.start), heading=self.heading, robot_valid_cells=int(self._robot_valid.sum()),
            reachable_cells=int(self._reachable.sum()), directed_swept_edges=int(self._edge_valid.sum()),
            semantic_reference_sha256=sha(SEMANTIC_REFERENCE), elapsed_s=time.monotonic()-start_time,
            collision_model=GEOMETRY_VERSION, collision_height_m=list(COLLISION_BAND_M),
            floor_support_height_m=list(FLOOR_BAND_M), floor_normal_min=FLOOR_NORMAL_MIN,
            evaluator_truth_never_in_sensor_packet=True)

    def xy(self, cell):
        r, c = cell
        return ((c+.5)*self.config.resolution_m,
                (self.shape[0]-r-.5)*self.config.resolution_m)

    def _build_evaluator_topology(self):
        key_data = dict(version=GEOMETRY_VERSION, transform=self.world_from_source.tolist(),
            shape=self.shape, radius=self.config.robot_radius_m, resolution=self.config.resolution_m,
            collision_band=COLLISION_BAND_M, floor_band=FLOOR_BAND_M,
            floor_normal_min=FLOOR_NORMAL_MIN, assembler=sha(BASE/'assets/replicacad/assemble_apt0.py'),
            assets=sha(BASE/'assets/replicacad/download_receipt.json'))
        self._topology_key = hashlib.sha256(json.dumps(key_data, sort_keys=True).encode()).hexdigest()
        cache_path = CACHE / (self._topology_key + '.npz')
        CACHE.mkdir(exist_ok=True)
        if cache_path.exists():
            with np.load(cache_path, allow_pickle=False) as arrays:
                self._occupancy = arrays['occupancy'].copy()
                self._robot_valid = arrays['robot_valid'].copy()
                self._edge_valid = arrays['edge_valid'].copy()
            return
        self._occupancy = np.ones(self.shape, bool)
        self._robot_valid = np.zeros(self.shape, bool)
        self._edge_valid = np.zeros((*self.shape, 4), bool)
        radius = self.config.robot_radius_m
        for cell in np.ndindex(self.shape):
            xy = self.xy(cell)
            self._occupancy[cell] = not self._geometry.valid(xy, radius=0.)
            self._robot_valid[cell] = self._geometry.valid(xy, radius=radius)
        # Explicit edge checks retain floor holes/thin obstacles between endpoints.
        for r, col in np.argwhere(self._robot_valid):
            cell = (int(r), int(col))
            for heading in (1, 2):
                dr, dc = DIRECTIONS[heading]
                target = (cell[0]+dr, cell[1]+dc)
                if (0 <= target[0] < self.shape[0] and 0 <= target[1] < self.shape[1]
                        and self._robot_valid[target]
                        and self._geometry.valid(self.xy(cell), self.xy(target), radius)):
                    self._edge_valid[cell+(heading,)] = True
                    self._edge_valid[target+((heading+2)%4,)] = True
        np.savez_compressed(cache_path, occupancy=self._occupancy,
            robot_valid=self._robot_valid, edge_valid=self._edge_valid)
        (CACHE/(self._topology_key+'.json')).write_text(json.dumps(key_data, indent=2)+'\n')

    def _flood(self, start):
        reachable = np.zeros(self.shape, bool)
        if not self._robot_valid[start]:
            return reachable
        queue = deque([start]); reachable[start] = True
        while queue:
            cell = queue.popleft()
            for h, (dr, dc) in enumerate(DIRECTIONS):
                target = (cell[0]+dr, cell[1]+dc)
                if self._edge_valid[cell+(h,)] and not reachable[target]:
                    reachable[target] = True; queue.append(target)
        return reachable

    @property
    def occupancy(self):
        """EVALUATOR ONLY: zero-radius point-centre obstacle/unsupported-floor mask."""
        return self._occupancy.copy()

    @property
    def reachable(self):
        """EVALUATOR ONLY: same fully swept circular motion graph as actual steps."""
        return self._reachable.copy()

    def evaluator_truth(self):
        return dict(occupancy=self.occupancy, reachable=self.reachable,
                    robot_valid=self._robot_valid.copy(), edge_valid=self._edge_valid.copy())

    def _render(self):
        # Static sensor geometry/texture cache only; timestamps remain per action.
        key = (self.position, self.heading, self.config.width_px, self.config.height_px,
               self.config.max_depth_m)
        if key not in self._frame_cache:
            c = self.config
            camera = camera_pose(self.position, self.heading, c, self.shape[0])
            source_camera = self.source_from_world @ camera
            rendered = self._renderer.render(self.intrinsic, source_camera, c.width_px, c.height_px,
                max_depth_m=c.max_depth_m, min_depth_m=.15)
            gids = rendered['reference_geometry_id']; depth = rendered['depth_m']
            labels = np.zeros(depth.shape, np.uint8)
            valid = depth > 0
            for gid in self._open_gids:
                labels[(gids == gid) & valid] = 2
            v, u = np.mgrid[:c.height_px, :c.width_px]
            directions = np.stack(((u-self.intrinsic[0,2])/self.intrinsic[0,0],
                (v-self.intrinsic[1,2])/self.intrinsic[1,1], np.ones_like(u)), axis=-1)
            source_points = source_camera[:3,3] + (directions @ source_camera[:3,:3].T)*depth[...,None]
            for gid, low, high in self._closed_regions:
                inside = np.all(source_points >= low-1e-6, axis=-1) & np.all(source_points <= high+1e-6, axis=-1)
                labels[(gids == gid) & inside & valid] = 3
            self._frame_cache[key] = (depth.copy(), rendered['rgb'].copy(), labels, camera)
        return self._frame_cache[key]

    def sense(self):
        c = self.config
        depth, rgb, labels, camera = self._render()
        depth, rgb, labels = depth.copy(), rgb.copy(), labels.copy()
        if c.depth_sigma_m or c.dropout:
            rng = np.random.default_rng(np.random.SeedSequence([self.seed,self.step_count,739]))
            noisy = depth + rng.normal(0,c.depth_sigma_m,depth.shape)
            valid = (depth>0) & (rng.random(depth.shape)>=c.dropout) & (noisy>.15) & (noisy<=c.max_depth_m)
            depth = np.where(valid,noisy,0.).astype(np.float32)
            labels[~valid] = 0
        return RGBDFrame(self.step_count*c.action_duration_s, depth, rgb,
            self.intrinsic.copy(), camera.copy(), labels).validate()

    def scan(self):
        c = self.config
        camera = camera_pose(self.position,self.heading,c,self.shape[0])
        laser = np.eye(4); laser[:3,0] = camera[:3,2]; laser[:3,1] = -camera[:3,0]
        laser[:3,3] = camera[:3,3]; laser[2,3] = c.laser_height_m
        angles = -np.pi + np.arange(c.laser_rays)*2*np.pi/c.laser_rays
        local = np.column_stack((np.cos(angles),np.sin(angles),np.zeros_like(angles)))
        source_laser = self.source_from_world @ laser
        rays = np.column_stack((np.tile(source_laser[:3,3],(len(angles),1)),local@source_laser[:3,:3].T)).astype(np.float32)
        ranges = self._ray.cast_rays(o3d.core.Tensor(rays),nthreads=1)['t_hit'].numpy()
        ranges = np.minimum(ranges,c.max_depth_m).astype(np.float32)
        if not np.all(np.isfinite(ranges) & (ranges>0)):
            raise ValueError('Laser starts on/inside mesh or produced invalid range')
        return PlanarScan(self.step_count*c.action_duration_s,ranges,-np.pi,
            2*np.pi/c.laser_rays,c.max_depth_m,laser)

    def step(self, action):
        if action not in ('forward','left','right','stop'):
            raise ValueError('unknown action')
        self.step_count += 1
        collision = False
        if action == 'forward':
            if not self._edge_valid[self.position+(self.heading,)]:
                collision = True; self.collisions += 1
            else:
                dr, dc = DIRECTIONS[self.heading]
                self.position = (self.position[0]+dr, self.position[1]+dc); self.moves += 1
        elif action in ('left','right'):
            # Circular footprint is invariant under in-place heading rotation.
            self.heading = (self.heading+(1 if action=='right' else -1)) % 4
        return self.sense(), collision, action == 'stop' or self.step_count >= self.config.max_steps


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true', help='Build geometry/topology and one sensor frame; no policy or rollout')
    args = parser.parse_args()
    if args.prepare:
        world = ReplicaCADWorld(); frame = world.sense(); scan = world.scan()
        print(json.dumps(dict(world.geometry_receipt, initial_valid_depth_pixels=int((frame.depth_m>0).sum()),
                              initial_class_counts={str(x):int((frame.semantic==x).sum()) for x in (0,2,3)}), indent=2))
