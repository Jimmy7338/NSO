#!/usr/bin/env python3
"""Paired C/G/S on one ReplicaCAD layout; no ROS/hardware or implicit batch."""
import argparse
import dataclasses
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD_RUNNER=Path('/home/ouc/nso_robot/analyses/four_room_completion_20261119/matrix_study/run.py')
spec=importlib.util.spec_from_file_location('frozen_matrix_outer_helpers',OLD_RUNNER)
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
SOURCE=base.SOURCE
sha=base.sha
write=base.write
source_hashes=base.source_hashes


def protocol():
    return json.loads((HERE/'protocol.json').read_text())


def dependencies():
    base.dependencies()
    sys.path.insert(0,str(ROOT))
    sys.path.insert(0,str(ROOT/'scene_adapter'))


def adapter_hashes():
    paths=[ROOT/'scene_adapter/replicacad_world.py',ROOT/'assets/textured_raycast.py',
           ROOT/'assets/replicacad/assemble_apt0.py',
           ROOT/'assets/replicacad/download_receipt.json',
           ROOT/'scene_adapter/horizontal_living/PROTOCOL.json',
           ROOT/'exploration_evaluation/structural_reference_low.json',OLD_RUNNER]
    return {str(p):sha(p) for p in paths}


def asset_hashes():
    asset=ROOT/'assets/replicacad'
    paths=[]
    for name in ('configs','objects','stages','urdf','navmeshes'):
        paths += [p for p in (asset/name).rglob('*') if p.is_file()]
    return {str(p.relative_to(asset)):sha(p) for p in sorted(set(paths))}


def library_versions():
    from importlib.metadata import version
    return dict(python=sys.version,**{name:version(name) for name in ('numpy','scipy','open3d','trimesh','shapely','torch')})


def packet(world,tr,frame,action=None,collision=False,done=False,arm='G'):
    import numpy as np
    from nso.cpu_sensor_contract_v10 import SensorPacket
    assert np.isin(frame.semantic,(0,2,3)).all()
    assert not np.any(frame.semantic[frame.depth_m==0])
    absent=arm=='S_no_semantics'
    if absent:frame=dataclasses.replace(frame,semantic=np.zeros_like(frame.semantic))
    return SensorPacket(protocol()['scene']['id'],'identical_sensor_cold_start',
        f'frame-{world.step_count}',int(world.step_count),frame,world.scan(),
        tuple(map(int,world.position)),int(world.heading),
        'textured_mesh_RGBD_scan_absent_structural_labels' if absent else 'textured_mesh_RGBD_scan_partial_oracle_verified_parts',
        'exact_discrete_odometry',action,bool(collision),bool(done)).validate(tr,world.config)


def nonsemantic_packet_sha(p):
    import numpy as np
    return dataclasses.replace(p,frame=dataclasses.replace(p.frame,semantic=np.zeros_like(p.frame.semantic)),
        sensor_source='same_sensor_bytes_without_semantic_labels').sha256()


def world_and_packet(arm='G'):
    from nso.cpu_sensor_contract_v10 import GridTransform
    from replicacad_world import ReplicaCADConfig,ReplicaCADWorld
    cfg=protocol()['environment']
    world=ReplicaCADWorld(ReplicaCADConfig(**cfg['config']),seed=cfg['noise_seed'])
    assert list(world.position)==cfg['initial_position'] and world.heading==cfg['initial_heading']
    tr=GridTransform(tuple(map(int,world.shape)),world.config.resolution_m)
    return world,tr,packet(world,tr,world.sense(),arm=arm)


def evaluate(belief,reference):
    """Evaluation-only reference; none of this object is passed into policy."""
    import numpy as np
    count=int(np.count_nonzero(reference))
    assert count>0
    known=int(np.count_nonzero((belief!=-1)&reference))
    free=int(np.count_nonzero((belief==0)&reference))
    occupied=int(np.count_nonzero((belief==1)&reference))
    return dict(reference_free_cells=count,known_cells=known,correctly_free_cells=free,
        false_occupied_cells=occupied,coverage_fraction=known/count,
        free_correct_fraction=free/count,false_occupied_fraction=occupied/count)


def prepare():
    import numpy as np
    from nso.observed_runtime_mapper_v10 import ObservedRuntimeMapperV10
    out=HERE/'prepared';out.mkdir(exist_ok=False)
    try:
        world,tr,p=world_and_packet()
        mapper=ObservedRuntimeMapperV10(world.shape,world.config)
        assert np.all(mapper.belief==-1)
        mapper.update(p.frame,p.scan)
        np.savez_compressed(out/'initial_sensor.npz',depth_m=p.frame.depth_m,rgb=p.frame.color_rgb,
            visible_partial_structural_labels=p.frame.semantic,intrinsic=p.frame.intrinsic,
            world_from_camera=p.frame.world_from_camera,scan_m=p.scan.ranges_m,
            world_from_laser=p.scan.world_from_laser)
        np.savez_compressed(out/'evaluator_truth.npz',**world.evaluator_truth())
        p.frame.save(out/'initial_frame.npz');p.scan.save(out/'initial_scan.npz')
        initial=dict(scene_id=protocol()['scene']['id'],scene_role=protocol()['scene']['role'],
            layout_count=1,anchor=[*world.position,world.heading],shape=world.shape,
            actual_config=dataclasses.asdict(world.config),initial_packet_sha256=p.sha256(),
            initial_packet_sha256_by_arm={a:packet(world,tr,p.frame,arm=a).sha256() for a in protocol()['arms']},
            nonsemantic_initial_packet_sha256=nonsemantic_packet_sha(p),
            initial_semantic_pixels={str(c):int((p.frame.semantic==c).sum()) for c in (0,2,3)},
            evaluation=evaluate(mapper.belief,world.reachable),motion_steps=int(world.step_count),
            current_footprint_conflict=bool(mapper.current_footprint_conflict),
            natural_semantic_detector=False,partial_oracle_labels=True,
            world_reference_metadata=world.geometry_receipt)
        assert world.step_count==0
        write(out/'initial_state.json',initial)
        files={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()}
        cache=ROOT/'scene_adapter/precomputed_assets'/(world.geometry_receipt['topology_cache_key']+'.npz')
        write(out/'freeze.json',dict(protocol_sha256=sha(HERE/'protocol.json'),runner_sha256=sha(__file__),
            scientific_source_sha256=source_hashes(),adapter_sha256=adapter_hashes(),
            asset_sha256=asset_hashes(),library_versions=library_versions(),
            geometry_cache=dict(path=str(cache),sha256=sha(cache)),
            prepared_files_sha256=files,created_unix_s=time.time()))
        print(json.dumps(initial),flush=True)
    except BaseException as exc:
        write(out/'prepare_failure.json',dict(error=repr(exc),traceback=traceback.format_exc()))
        raise


def verify():
    out=HERE/'prepared';f=json.loads((out/'freeze.json').read_text())
    assert sha(HERE/'protocol.json')==f['protocol_sha256'],'protocol changed'
    assert sha(__file__)==f['runner_sha256'],'runner changed'
    assert source_hashes()==f['scientific_source_sha256'],'scientific source changed'
    assert adapter_hashes()==f['adapter_sha256'],'adapter changed'
    assert asset_hashes()==f['asset_sha256'],'assets changed'
    assert library_versions()==f['library_versions'],'library versions changed'
    assert sha(f['geometry_cache']['path'])==f['geometry_cache']['sha256'],'geometry cache changed'
    for name,value in f['prepared_files_sha256'].items():assert sha(out/name)==value,name
    return json.loads((out/'initial_state.json').read_text())


def bootstrap(arm,initial_bundle=None):
    from types import SimpleNamespace
    from nso.components import NSO_Components
    from nso_bridge.exploration_joint_policy import ExplorationJointCPUFourModules,ExplorationJointRuntimeIntegration
    cfg=protocol()
    if initial_bundle is None:world,tr,p=world_and_packet(arm)
    else:
        world,tr,common=initial_bundle
        assert world.step_count==0
        p=packet(world,tr,common.frame,arm=arm)
    effective=dict(cfg['policy']['args']);effective.update(cpu_score_mode=cfg['arms'][arm]['score_mode'],
        cpu_freeze_gain_posterior=False,run_id=f'ReplicaCAD-apt0-{arm}')
    args=SimpleNamespace(**effective)
    comp=NSO_Components(args);comp.initialize('cpu',1,*world.shape,*world.shape)
    comp._cpu_backend=ExplorationJointCPUFourModules(args,1,world.shape)
    comp.capabilities=dict(comp._cpu_backend.capabilities)
    runtime=ExplorationJointRuntimeIntegration(comp,1,world.shape)
    runtime.start_sensor_episode(0,config=world.config,transform=tr,packets=[p],
        total_budget=cfg['policy']['paid_action_budget'],return_anchor=(*p.position,p.heading),paid_prefix_actions=0)
    state=comp._cpu_backend.scenes[0]
    assert state['ledger'].feedback_enabled and state['gain'].feedback_enabled
    assert not state['gain'].consume_predicted_attempts
    assert not args.cpu_force_gain_feedback and not args.cpu_disable_feedback
    assert world.config.max_steps==cfg['policy']['paid_action_budget']
    assert comp._cpu_backend.planner_revision=='v10_3_1'
    audit=dict(arm=arm,effective_args=effective,backend=type(comp._cpu_backend).__name__,
        policy_variant=comp._cpu_backend.policy_variant,initial_packet_sha256=p.sha256(),
        capability_note=cfg['policy']['capability_note'],capabilities=comp.capabilities,
        hidden_truth_to_actor=False,partial_oracle_semantics=arm!='S_no_semantics',
        semantic_labels_absent=arm=='S_no_semantics',initial_prefix_actions=0)
    return world,tr,p,comp,runtime,audit


def mechanism_probe(state,p,plan):
    """Describe native mechanism activation without changing or supplying inputs."""
    import numpy as np
    from scipy.ndimage import binary_closing,label
    from nso.response_features_v7 import ResponseFeatureConfig
    mapper=state['mapper'];q=mapper.quality_evidence(max_points=10000)
    group_audit=[]
    # Reproduce only grouping diagnostics, never feed these records into policy.
    if q is not None:
        points=q['point'];cells=np.column_stack([mapper.shape[0]-1-np.floor(points[:,1]/.2),np.floor(points[:,0]/.2)]).astype(int)
        inside=((cells>=0)&(cells<np.array(mapper.shape))).all(axis=1)
        occupied=np.zeros(mapper.shape,bool);occupied[tuple(cells[inside].T)]=True
        groups,_=label(binary_closing(occupied,structure=np.ones((3,3))))
        ids=np.zeros(len(points),int);ids[inside]=groups[tuple(cells[inside].T)]
        limits=ResponseFeatureConfig()
        for group in sorted(set(ids)-{0}):
            selected=ids==group;cloud=points[selected];lo,hi=np.quantile(cloud,[.05,.95],axis=0);span=hi-lo
            reasons=[]
            if len(cloud)<limits.min_support_points:reasons.append('min_support_points')
            if max(span[:2])>limits.max_horizontal_extent_m:reasons.append('max_horizontal_extent')
            if span[2]<limits.min_vertical_extent_m:reasons.append('min_vertical_extent')
            group_audit.append(dict(group=int(group),support_points=len(cloud),span_m=span,
                marked_counts={str(c):int((q['label'][selected]==c).sum()) for c in (2,3)},
                rejected_by_original_grouping=reasons,quantile_bounds_m=[lo,hi]))
    assets=[]
    for a in state['assets']:
        assets.append({k:a[k] for k in ('group','marked_points','class_vote','aabb_center',
            'measured_width_m','measured_depth_m','measured_height_m','front_axis','back_axis') if k in a})
    score_rows=[dict(candidate_id=r['candidate_id'],common=r['common_total_proxy'],
        coverage=r['coverage_only_proxy'],quality=r['quality_total_proxy'],
        prior_G=r['prior_potentials']['G'],prior_S=r['prior_potentials']['S'],
        incremental_aperture=r['incremental_aperture']) for r in plan['score_audit']]
    audit=plan['candidate_audit']
    return dict(visible_semantic_pixels={str(c):int((p.frame.semantic==c).sum()) for c in (0,2,3)},
        all_measured_quality_labels={str(c):sum(r['label']==c for r in mapper.quality.values()) for c in (0,2,3)},
        asset_grouping_quality_labels_10000cap={str(c):0 if q is None else int((q['label']==c).sum()) for c in (0,2,3)},
        score_asset_count=len(assets),score_assets=assets,candidate_asset_count=audit['observed_asset_count'],
        original_grouping_diagnostics=group_audit,
        gain_posterior=state['gain'].snapshot()['posterior_mean'],
        structure_representation='Observed class_vote and area prior; no complete two-template posterior',
        available_roles=audit.get('available_roles',[]),missing_roles=audit['missing_roles'],
        asset_target_reasons=audit['target_audit'],candidates=score_rows,
        semantic_prior_differs=any(abs(r['prior_S']-r['prior_G'])>1e-12 for r in score_rows),
        candidate_status=audit['status'])


def selfcheck():
    from nso.cpu_sensor_contract_v10 import digest
    initial=verify();rows={};signatures=[]
    shared_initial=world_and_packet()
    for arm in protocol()['arms']:
        world,tr,p,comp,runtime,effective=bootstrap(arm,shared_initial)
        assert p.sha256()==initial['initial_packet_sha256_by_arm'][arm]
        assert nonsemantic_packet_sha(p)==initial['nonsemantic_initial_packet_sha256']
        comp._cpu_backend.select_target(0)
        state=comp._cpu_backend.scenes[0];plan=state['last_selection']
        signature=(digest(plan['candidates']),digest(runtime.states[0]['mapper'].belief))
        assert world.step_count==0
        signatures.append(signature)
        rows[arm]=dict(effective=effective,candidate_sha256=signature[0],belief_sha256=signature[1],
            first_plan=plan,mechanism=mechanism_probe(state,p,plan),paid_actions=0,world_motion_steps=0)
    assert len(set(signatures))==1,'initial candidates or geometry differ'
    for i,a in enumerate(rows['G']['first_plan']['score_audit']):
        assert abs(rows['G']['first_plan']['scores']['G'][i]-(a['common_total_proxy']+a['prior_potentials']['G']))<1e-9
        assert abs(rows['C']['first_plan']['scores']['C'][i]-a['coverage_only_proxy'])<1e-9
    if 'X' in rows:
        assert rows['X']['first_plan']['scores']['S']==rows['S']['first_plan']['scores']['S']
    absent_equivalence=None
    if 'S_no_semantics' in rows:
        absent_equivalence=rows['S_no_semantics']['first_plan']['scores']['S']==rows['G']['first_plan']['scores']['G']
    write(HERE/'selfcheck.json',dict(status='passed',simulator_actions=0,
        scope='First-state input/config/scoring equality only; no completed trajectory',
        S_no_semantics_scores_equal_G_at_first_state=absent_equivalence,arms=rows))
    write(HERE/'mechanism_summary.json',{arm:row['mechanism'] for arm,row in rows.items()})
    print(json.dumps(dict(status='passed',simulator_actions=0,candidates=len(rows['G']['first_plan']['candidates']))),flush=True)


def new_attempt(arm):
    parent=HERE/'runs'/arm;parent.mkdir(parents=True,exist_ok=True)
    for i in range(1,10000):
        p=parent/f'attempt_{i:03d}'
        try:p.mkdir();return p
        except FileExistsError:continue
    raise RuntimeError('attempt index exhausted')


def run(arm):
    import numpy as np
    initial=verify();cfg=protocol();out=new_attempt(arm)
    start=time.monotonic();steps=[];choices=[];timings=[];mapper=world=runtime=None
    write(out/'attempt.json',dict(status='started',arm=arm,scene_id=initial['scene_id'],layout_count=1,
        started_unix_s=time.time(),protocol_sha256=sha(HERE/'protocol.json'),runner_sha256=sha(__file__),
        prepared_freeze_sha256=sha(HERE/'prepared/freeze.json'),paid_action_budget=cfg['policy']['paid_action_budget']))
    def interrupted(signum,frame):raise InterruptedError(f'external signal {signum}; not an algorithmic outcome')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        world,tr,p,comp,runtime,effective=bootstrap(arm)
        assert p.sha256()==initial['initial_packet_sha256_by_arm'][arm]
        assert nonsemantic_packet_sha(p)==initial['nonsemantic_initial_packet_sha256']
        write(out/'effective_configuration.json',effective)
        mapper=runtime.states[0]['mapper'];first=evaluate(mapper.belief,world.reachable)
        write(out/'initial_evaluation.json',first)
        streak=0
        while not runtime.states[0]['closed']:
            t=time.monotonic();action=runtime.next_local_action(0);decision=time.monotonic()-t
            timings.append(decision)
            choices=[dict(inputs=x['inputs'],outputs=x['outputs'],
                call_metadata={k:v for k,v in x.items() if k not in ('inputs','outputs')})
                for x in comp._cpu_backend.calls if x['method']=='select_topo_target']
            write(out/'choices.json',choices);write(out/'runtime_audit.json',runtime.audit)
            if action is None:break
            active=runtime.states[0]['option'];phase=runtime.states[0]['phase']
            target=None if active is None else list(active['pose'])
            option=None if active is None else active['option_id']
            known_before=(mapper.belief!=-1).copy()
            t=time.monotonic();frame,collision,done=world.step(action);p=packet(world,tr,frame,action,collision,done,arm=arm)
            sensor_time=time.monotonic()-t
            t=time.monotonic();runtime.observe(0,world.step_count,None,None,None,sensor_packet=p)
            observe_time=time.monotonic()-t
            measured=evaluate(mapper.belief,world.reachable)
            newly_known=int(np.count_nonzero((mapper.belief!=-1)&~known_before&world.reachable))
            streak=streak+1 if newly_known==0 else 0
            steps.append(dict(step=world.step_count,action=action,position=list(world.position),heading=world.heading,
                **measured,new_reference_known_cells=newly_known,zero_coverage_gain_streak=streak,
                path_length_m=world.moves*world.config.resolution_m,collision=bool(collision),done=bool(done),
                packet_sha256=p.sha256(),active_option_id=option,selected_target_pose=target,phase_before_action=phase,
                matched_target_pose_after_step=target==[*world.position,world.heading] if target is not None else None,
                decision_wall_s=decision,sensor_wall_s=sensor_time,observe_wall_s=observe_time,
                partial_semantic_pixels={str(c):int((p.frame.semantic==c).sum()) for c in (0,2,3)},
                measured_patch_count=len(mapper.quality),gain_posterior=comp._cpu_backend.scenes[0]['gain'].snapshot()['posterior_mean']))
            write(out/'steps.json',steps);write(out/'heartbeat.json',dict(step=world.step_count,
                elapsed_s=time.monotonic()-start,coverage_fraction=measured['coverage_fraction']))
        summary=runtime.sensor_episode_summary(0)
        write(out/'episode_summary.json',summary);write(out/'runtime_audit.json',runtime.audit)
        geometry=base.export_geometry(out,mapper,world)
        write(out/'final_gain_calibration.json',comp._cpu_backend.scenes[0]['gain'].snapshot())
        final=evaluate(mapper.belief,world.reachable)
        def hits(field):
            return {str(x):0 if first[field]>=x else next((r['step'] for r in steps if r[field]>=x),None) for x in cfg['evaluation']['thresholds']}
        verify()
        trace=json.dumps([(r['action'],r['position'],r['heading']) for r in steps],sort_keys=True).encode()
        result=dict(status='completed_execution',arm=arm,scene_id=initial['scene_id'],scene_role=initial['scene_role'],
            independent_layouts=1,paid_actions=len(steps),paid_action_budget=cfg['policy']['paid_action_budget'],
            initial_coverage_fraction=first['coverage_fraction'],final_coverage_fraction=final['coverage_fraction'],
            final_evaluation=final,free_correct_fraction=final['free_correct_fraction'],
            false_occupied_fraction=final['false_occupied_fraction'],reference_free_cells=final['reference_free_cells'],
            first_coverage_action=hits('coverage_fraction'),first_free_correct_action=hits('free_correct_fraction'),
            path_length_m=world.moves*world.config.resolution_m,turn_actions=sum(r['action'] in ('left','right') for r in steps),
            collisions=world.collisions,termination=summary['termination'],
            final_pose=[*world.position,world.heading],final_pose_equals_initial_anchor=[*world.position,world.heading]==initial['anchor'],
            zero_gain_actions=sum(r['new_reference_known_cells']==0 for r in steps),
            longest_zero_gain_streak=max((r['zero_coverage_gain_streak'] for r in steps),default=0),
            target_pose_matches=sum(r['matched_target_pose_after_step'] is True for r in steps),
            initial_packet_sha256=initial['initial_packet_sha256_by_arm'][arm],
            nonsemantic_initial_packet_sha256=initial['nonsemantic_initial_packet_sha256'],
            trajectory_sha256=hashlib.sha256(trace).hexdigest(),global_planning_calls=len(choices),
            decision_wall_s_total=sum(timings),elapsed_s=time.monotonic()-start,quality_export=geometry,
            reconstruction_accuracy_evaluated=False,partial_oracle_semantics=arm!='S_no_semantics',
            semantic_labels_absent=arm=='S_no_semantics',natural_detector=False,
            measured_patch_count=len(mapper.quality),effective_args=effective['effective_args'],
            source_and_adapter_hashes_unchanged=True)
        write(out/'result.json',result)
        write(out/'artifact_manifest.json',dict(status='completed_execution',files_sha256={p.name:sha(p) for p in out.iterdir() if p.is_file()}))
        print(json.dumps(dict(output=str(out),**result)),flush=True)
    except BaseException as exc:
        write(out/'failure.json',dict(status='interrupted' if isinstance(exc,(InterruptedError,KeyboardInterrupt)) else 'failed',
            error=repr(exc),traceback=traceback.format_exc(),paid_actions=len(steps),elapsed_s=time.monotonic()-start,
            completed_episode=False,final_return_claim=False))
        if runtime is not None:write(out/'runtime_audit.json',runtime.audit)
        if mapper is not None:
            try:
                partial=out/'partial_geometry';partial.mkdir()
                base.export_geometry(partial,mapper,world)
                write(partial/'PARTIAL_ONLY.json',dict(completed_episode=False,paid_actions=len(steps)))
            except Exception as save_error:write(out/'partial_export_failure.json',dict(error=repr(save_error)))
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('prepare','verify','selfcheck','run'))
    parser.add_argument('--arm',choices=tuple(protocol()['arms']))
    args=parser.parse_args();dependencies()
    if args.command=='prepare':prepare()
    elif args.command=='verify':print(json.dumps(verify()))
    elif args.command=='selfcheck':selfcheck()
    elif args.arm is None:parser.error('run requires --arm; no implicit batch')
    else:run(args.arm)


if __name__=='__main__':main()
