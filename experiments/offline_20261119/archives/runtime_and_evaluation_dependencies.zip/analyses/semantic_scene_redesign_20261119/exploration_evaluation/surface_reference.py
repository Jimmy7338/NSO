"""Independent scan-asset surface reference. Never imported by the actor.

Natural meshes are sampled directly. Fixed reachable camera visibility removes
occluded/internal surfaces from the completeness denominator. Reconstruction
accuracy uses distance to actual source mesh, not sampled-point NN distance.
"""
from pathlib import Path
import json
import sys
import numpy as np
import open3d as o3d
import trimesh

BASE=Path(__file__).resolve().parents[1]
SOURCE=Path('/home/ouc/nso_robot/analyses/reproduction_20261104/simulation_publication_stage/experiments/unknown_exploration_20261104/source')
sys.path[:0]=[str(BASE/'assets/replicacad'),str(SOURCE)]
from assemble_apt0 import build
from env.virtual3d import camera_pose
from utils.reconstruction_metrics import surface_samples,ray_scene

LOW_REFERENCE=Path(__file__).with_name('structural_reference_low.json')


def source_mesh(world_from_source):
    """Return exact assembled geometry and evaluator-only target triangle IDs."""
    scene,records,node_metadata=build()
    vertices=[];faces=[];target_ids=[];offset=0;nodes=[]
    for node in scene.graph.nodes_geometry:
        local,name=scene.graph[node];mesh=scene.geometry[name]
        points=trimesh.transform_points(mesh.vertices,np.asarray(world_from_source)@local)
        triangles=np.asarray(mesh.faces,np.int32)
        source=node_metadata[node];instance=source['instance_id']
        target=31 if instance==31 else (116 if instance==116 and '/kitchencupboard_doorWhole_' in node else 0)
        vertices.append(points);faces.append(triangles+offset);target_ids.extend([target]*len(triangles))
        nodes.append({'node':node,'instance':instance,'target':target,'triangles':len(triangles)})
        offset+=len(points)
    mesh=o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(np.concatenate(vertices)),
        o3d.utility.Vector3iVector(np.concatenate(faces)))
    return mesh,np.asarray(target_ids,np.int16),nodes


def unique_sampling_faces(mesh,labels,quantum_m=1e-7):
    """Deduplicate exact coincident triangles only, preserving full ray mesh.

The source geometry/BVH is unchanged. Quantization at 0.1 micrometre protects
determinism from insignificant serialized floating point differences.
"""
    triangles=np.asarray(mesh.vertices)[np.asarray(mesh.triangles)]
    quantized=np.rint(triangles/quantum_m).astype(np.int64)
    ordered=np.sort(quantized.view([('x','i8'),('y','i8'),('z','i8')]).reshape(quantized.shape[:2]),axis=1)
    keys=np.ascontiguousarray(ordered).view(np.dtype((np.void,ordered.dtype.itemsize*3))).reshape(-1)
    _,keep=np.unique(keys,return_index=True);keep=np.sort(keep)
    filtered=o3d.geometry.TriangleMesh(mesh.vertices,o3d.utility.Vector3iVector(np.asarray(mesh.triangles)[keep]))
    return filtered,np.asarray(labels)[keep],{'raw_triangles':len(triangles),'unique_sampling_triangles':len(keep),
        'removed_exact_coincident_triangles':len(triangles)-len(keep),'coincidence_quantum_m':quantum_m}


def subset_mesh(mesh,triangle_mask):
    return o3d.geometry.TriangleMesh(mesh.vertices,
        o3d.utility.Vector3iVector(np.asarray(mesh.triangles)[triangle_mask]))


def clipped_low_reference_mesh(world_from_source):
    """Exact source triangles clipped to independently verified front regions.

    This clips the actual natural mesh to the explicit evaluator ROI, not a
    box completion/union formula or fabricated replacement geometry.
    """
    scene,_,_=build();definition=json.loads(LOW_REFERENCE.read_text());vertices=[];faces=[]
    def clip(poly,axis,bound,lower):
        if not len(poly):return []
        out=[];previous=np.asarray(poly[-1]);pinside=(previous[axis]>=bound if lower else previous[axis]<=bound)
        for point in poly:
            point=np.asarray(point);inside=(point[axis]>=bound if lower else point[axis]<=bound)
            if inside!=pinside:
                ratio=(bound-previous[axis])/(point[axis]-previous[axis]);out.append(previous+ratio*(point-previous))
            if inside:out.append(point)
            previous=point;pinside=inside
        return out
    for row in definition['node_whitelist_with_source_bounds']:
        local,name=scene.graph[row['node']];mesh=scene.geometry[name]
        points=trimesh.transform_points(mesh.vertices,local)
        lo,hi=np.asarray(row['source_xyz_min_m']),np.asarray(row['source_xyz_max_m'])
        for triangle in points[np.asarray(mesh.faces)]:
            poly=list(triangle)
            for axis in range(3):poly=clip(poly,axis,lo[axis],True);poly=clip(poly,axis,hi[axis],False)
            if len(poly)<3:continue
            poly=trimesh.transform_points(np.asarray(poly),np.asarray(world_from_source))
            offset=len(vertices);vertices.extend(poly)
            faces.extend([[offset,offset+i,offset+i+1] for i in range(1,len(poly)-1)])
    return o3d.geometry.TriangleMesh(o3d.utility.Vector3dVector(np.asarray(vertices)),
        o3d.utility.Vector3iVector(np.asarray(faces,np.int32)))


def fixed_camera_poses(reachable,config,start):
    """Pose set is independent of all tested reconstruction/trajectory outputs."""
    reachable=np.asarray(reachable,bool);cells=np.argwhere(reachable)
    lattice=[tuple(map(int,p)) for p in cells if p[0]%4==0 and p[1]%4==0]
    start=tuple(map(int,start));assert reachable[start]
    if start not in lattice:lattice.append(start)
    lattice=sorted(lattice)
    poses=[camera_pose(cell,h,config,reachable.shape[0]) for cell in lattice for h in range(4)]
    return np.asarray(poses),lattice


def visible_reference(points,truth,poses,config,tolerance_m=.001):
    visible=np.zeros(len(points),bool);first_pose=np.full(len(points),-1,np.int32)
    tan_h=np.tan(np.deg2rad(config.fov_deg/2));tan_v=tan_h*config.height_px/config.width_px
    ray_count=0
    for i,pose in enumerate(poses):
        ids=np.flatnonzero(~visible)
        if not len(ids):break
        delta=points[ids]-pose[:3,3];local=delta@pose[:3,:3]
        axial=local[:,2]
        # Continuous pinhole footprint includes the outer half-pixel extent.
        possible=(axial>=.15)&(axial<=config.max_depth_m)&(np.abs(local[:,0])<=axial*tan_h)&(np.abs(local[:,1])<=axial*tan_v)
        ids=ids[possible];delta=delta[possible]
        if not len(ids):continue
        rays=np.c_[np.tile(pose[:3,3],(len(ids),1)),delta].astype(np.float32)
        distance=np.linalg.norm(delta,axis=1)
        hits=truth.cast_rays(o3d.core.Tensor(rays),nthreads=1)['t_hit'].numpy();ray_count+=len(rays)
        hit=np.isfinite(hits)&(np.abs(hits-1.)*distance<=tolerance_m)
        visible[ids[hit]]=True;first_pose[ids[hit]]=i
    return visible,first_pose,ray_count


def prepare_reference(world_from_source,reachable,config,start,global_count=100000,target_count=10000,seed=20261119):
    mesh,labels,nodes=source_mesh(world_from_source);truth=ray_scene(mesh)
    sampling_mesh,sampling_labels,duplicates=unique_sampling_faces(mesh,labels)
    poses,cells=fixed_camera_poses(reachable,config,start)
    reference={};metadata={}
    definitions=[('all',sampling_mesh,global_count,seed),
        ('open31',subset_mesh(sampling_mesh,sampling_labels==31),target_count,seed+31),
        ('closed115_fronts',clipped_low_reference_mesh(world_from_source),target_count,seed+115)]
    for name,candidate_mesh,count,random_seed in definitions:
        points,triangle_ids=surface_samples(candidate_mesh,count,random_seed)
        visible,seen,ray_count=visible_reference(points,truth,poses,config)
        reference[name]=points[visible].astype(np.float32)
        reference[name+'_first_pose']=seen[visible]
        metadata[name]={'drawn_area_samples':len(points),'visible_reference_samples':int(visible.sum()),
            'source_sampling_surface_area_m2':candidate_mesh.get_surface_area(),
            'estimated_camera_visible_area_m2':float(candidate_mesh.get_surface_area()*visible.mean()) if len(visible) else 0.,
            'seed':random_seed,'first_hit_rays_cast':ray_count}
    reference['camera_poses']=poses
    metadata.update(source_mesh_triangles=len(mesh.triangles),source_mesh_vertices=len(mesh.vertices),
        raw_source_mesh_area_m2=mesh.get_surface_area(),duplicate_sampling_handling=duplicates,
        reachable_cells=int(np.asarray(reachable).sum()),reference_lattice_cells=len(cells),reference_camera_poses=len(poses),
        reference_lattice_cell_list=cells,source_target_node_selection=[r for r in nodes if r['target']==31],
        closed_low_reference_definition=str(LOW_REFERENCE),
        reference_definition='Fixed0.8m reachable lattice plus start, four actual horizontal cardinal camera poses, calibrated FOV/axial8m, whole-source first-hit visibility within1mm; independent of tested trajectories',
        precision_definition='12k area samples of predicted TSDF evaluated by point-to-full-source-triangle distance',
        completeness_definition='Fixed visible area samples of source triangles evaluated by point-to-predicted-TSDF-triangle distance',
        target_precision_reported=False,target_reason='No predicted instance reconstruction is available; target completeness uses independently verified source subsets only',
        arbitrary_yaw_reference=False,geometry_truth_used_by_actor=False)
    return mesh,reference,metadata


def evaluate_surface(predicted_mesh,source_mesh,reference,thresholds=(.05,.10)):
    predicted,_=surface_samples(predicted_mesh,12000,812)
    source_ray=ray_scene(source_mesh)
    has_prediction=bool(len(predicted))
    accuracy=source_ray.compute_distance(o3d.core.Tensor(predicted.astype(np.float32)),nthreads=1).numpy() if has_prediction else np.empty(0)
    reconstruction=ray_scene(predicted_mesh) if has_prediction else None
    result={'predicted_surface_samples':len(predicted),'predicted_mesh_triangles':len(predicted_mesh.triangles),
        'surface_error_mean_m':float(accuracy.mean()) if has_prediction else None,
        'surface_error_p95_m':float(np.percentile(accuracy,95)) if has_prediction else None,
        'target_surface_metrics':{}}
    for name in ('all','open31','closed115_fronts'):
        points=reference[name];d=reconstruction.compute_distance(o3d.core.Tensor(points),nthreads=1).numpy() if has_prediction and len(points) else np.full(len(points),np.inf)
        row={'reference_samples':len(points),'completeness_error_mean_m':float(d.mean()) if len(d) and np.isfinite(d).all() else None,
             'completeness_error_p95_m':float(np.percentile(d,95)) if len(d) and np.isfinite(d).all() else None}
        for threshold in thresholds:
            tag=f'{round(threshold*100):02d}cm';recall=float(np.mean(d<=threshold)) if len(d) else None
            row['recall_'+tag]=recall
            if name=='all':
                precision=float(np.mean(accuracy<=threshold)) if has_prediction else 0.
                f1=(2*precision*recall/(precision+recall)) if recall is not None and precision+recall>0 else (0. if recall is not None else None)
                result.update({'precision_'+tag:precision,'recall_'+tag:recall,'f1_'+tag:f1})
        if name=='all':result.update({k:v for k,v in row.items() if not k.startswith('recall_')})
        else:result['target_surface_metrics'][name]=row
    return result
