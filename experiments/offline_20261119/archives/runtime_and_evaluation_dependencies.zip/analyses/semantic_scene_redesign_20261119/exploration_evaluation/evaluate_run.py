#!/usr/bin/env python3
"""Evaluate a completed native TSDF export against the fixed scene reference."""
import argparse,hashlib,json,os,time,traceback
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import numpy as np
import open3d as o3d
from surface_reference import evaluate_surface


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--attempt',required=True,type=Path)
    p.add_argument('--reference',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    try:
        manifest=json.loads((a.attempt/'artifact_manifest.json').read_text());assert manifest['status']=='completed_execution'
        for name,wanted in manifest['files_sha256'].items():assert sha(a.attempt/name)==wanted,name
        reference_receipt=json.loads((a.reference/'RECEIPT.json').read_text())
        assert sha(a.reference/'fixed_reference.npz')==reference_receipt['reference_npz_sha256']
        assert sha(a.reference/'source_mesh.ply')==reference_receipt['source_mesh_sha256']
        assert sha(a.reference/'PROTOCOL.json')==reference_receipt['protocol_sha256']
        for name,wanted in reference_receipt['source_inputs_sha256'].items():assert sha(name)==wanted,name
        reference=dict(np.load(a.reference/'fixed_reference.npz',allow_pickle=False))
        predicted=o3d.io.read_triangle_mesh(str(a.attempt/'final_tsdf_mesh.ply'))
        truth=o3d.io.read_triangle_mesh(str(a.reference/'source_mesh.ply'))
        metrics=evaluate_surface(predicted,truth,reference)
        result={'status':'completed_independent_surface_evaluation','source_attempt':str(a.attempt.resolve()),
            'metrics':metrics,'reference_sha256':reference_receipt['reference_npz_sha256'],
            'reference_protocol_sha256':reference_receipt['protocol_sha256'],'all_run_artifact_hashes_verified':True,
            'native_TSDF_mesh_sha256':sha(a.attempt/'final_tsdf_mesh.ply'),
            'source_artifact_manifest_sha256':sha(a.attempt/'artifact_manifest.json'),
            'evaluator_source_sha256':{str(x):sha(x) for x in [Path(__file__),Path(__file__).with_name('surface_reference.py')]},
            'no_actor_executed':True,'registration_performed':False,'surface_counts_are_not_accuracy':True,
            'target_precision_omitted':'No predicted per-instance reconstruction exists; target completeness is geometrically well-defined.',
            'limitations':['One inspected apartment is one development scene, not independent trials.',
                'Ideal visible structure labels and exact simulated pose do not validate natural recognition or robot SLAM.',
                'Source geometry is opaque first-hit scan/CAD representation; transparent material accuracy is not evaluated.'],
            'elapsed_s':time.monotonic()-start}
        (a.output/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
        print(json.dumps({'output':str(a.output),'metrics':metrics,'elapsed_s':result['elapsed_s']}),flush=True)
    except BaseException as error:
        (a.output/'failure.json').write_text(json.dumps({'error':repr(error),'traceback':traceback.format_exc(),
            'elapsed_s':time.monotonic()-start},indent=2)+'\n');raise


if __name__=='__main__':main()
