#!/usr/bin/env python3
"""Freeze a trajectory-independent surface reference after world preparation."""
import argparse,hashlib,json,os,time
from pathlib import Path
from types import SimpleNamespace
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
import numpy as np
import open3d as o3d
from surface_reference import BASE,SOURCE,prepare_reference,LOW_REFERENCE
from env.virtual3d import camera_pose


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--prepared',type=Path,required=True)
    parser.add_argument('--coordinates',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();start=time.monotonic();args.output.mkdir(parents=True,exist_ok=False)
    freeze=json.loads((args.prepared/'freeze.json').read_text())
    for name,wanted in freeze['prepared_files_sha256'].items():assert sha(args.prepared/name)==wanted,name
    initial=json.loads((args.prepared/'initial_state.json').read_text())
    coordinates=json.loads(args.coordinates.read_text());cfg=SimpleNamespace(**initial['actual_config'])
    assert cfg.resolution_m==.2 and cfg.robot_radius_m==.2 and cfg.max_depth_m==8.
    assert list(initial['shape'])==coordinates['map_shape']
    with np.load(args.prepared/'evaluator_truth.npz',allow_pickle=False) as data:reachable=data['reachable'].copy()
    with np.load(args.prepared/'initial_sensor.npz',allow_pickle=False) as data:
        pose=data['world_from_camera'].copy();intrinsic=data['intrinsic'].copy()
    assert np.allclose(pose,camera_pose(tuple(initial['anchor'][:2]),initial['anchor'][2],cfg,reachable.shape[0]),atol=1e-6)
    # Same source centre/axis transform as prior coordinate audit, now with
    # independently frozen runtime pixel calibration instead of 640x480.
    assert np.allclose(pose,np.asarray(coordinates['world_from_camera']),atol=1e-6)
    focal=cfg.width_px/(2*np.tan(np.deg2rad(cfg.fov_deg/2)))
    assert np.allclose(intrinsic,[[focal,0,(cfg.width_px-1)/2],[0,focal,(cfg.height_px-1)/2],[0,0,1]],atol=1e-6)
    inputs=[args.prepared/'freeze.json',args.prepared/'evaluator_truth.npz',args.prepared/'initial_state.json',
        args.coordinates,LOW_REFERENCE,Path(__file__),Path(__file__).with_name('surface_reference.py'),
        BASE/'assets/replicacad/assemble_apt0.py',SOURCE/'utils/reconstruction_metrics.py']
    hashes={str(p):sha(p) for p in inputs}
    protocol={'schema':'ReplicaCAD_independent_surface_reference_v1','global_area_samples':100000,
        'per_target_area_samples':10000,'source_seed':20261119,'predicted_area_samples':12000,'predicted_seed':812,
        'distance_thresholds_m':[.05,.10],'fixed_lattice_stride_cells':4,'include_start':True,
        'headings':[0,1,2,3],'camera_config':initial['actual_config'],'first_hit_tolerance_m':.001,
        'target_definitions':{'open31':'Whole original open structure instance31, with reachable first-hit visibility',
            'closed115_fronts':'Original triangle geometry clipped to exact source-XYZ whitelist regions from structural_reference_low.json'},
        'transparency':'Original first-hit opaque render model; no glass validation',
        'alignment':'Frozen shared metric coordinates; no ICP or best-fit registration per run',
        'independence':'Reference uses prepared start-reachable source geometry, never test actions/reconstructions',
        'source_inputs_sha256':hashes}
    (args.output/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    mesh,reference,metadata=prepare_reference(coordinates['world_from_source'],reachable,cfg,initial['anchor'][:2])
    np.savez_compressed(args.output/'fixed_reference.npz',**reference)
    assert o3d.io.write_triangle_mesh(str(args.output/'source_mesh.ply'),mesh)
    assert hashes=={p:sha(p) for p in hashes},'Reference inputs changed during preparation'
    receipt={'status':'fixed_surface_reference_prepared','metadata':metadata,'elapsed_s':time.monotonic()-start,
        'reference_npz_sha256':sha(args.output/'fixed_reference.npz'),'source_mesh_sha256':sha(args.output/'source_mesh.ply'),
        'protocol_sha256':sha(args.output/'PROTOCOL.json'),'source_inputs_sha256':hashes,
        'no_actor_executed':True,'robot_or_ROS_io':False,'original_assets_not_modified':True}
    (args.output/'RECEIPT.json').write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':receipt['status'],'reference_samples':{k:len(reference[k]) for k in ('all','open31','closed115_fronts')},
        'poses':metadata['reference_camera_poses'],'elapsed_s':receipt['elapsed_s']}),flush=True)


if __name__=='__main__':main()
