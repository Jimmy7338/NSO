"""CPU texture/vertex-colour ray renderer; no semantic inference or image synthesis.

Inputs are a trimesh.Scene with explicit graph transforms and an optical camera
pose (+z forward, +x right, +y down). Trimesh glTF UVs use lower-left origin;
PIL images use upper-left. Output depth is axial metres, not radial range.
This unlit renderer samples supplied textures; it does not simulate material
transparency, lighting, rolling shutter or a trained depth estimator.
"""
import numpy as np
import open3d as o3d
import trimesh


def look_at(eye,target,up=(0,1,0)):
    eye=np.asarray(eye,float);forward=np.asarray(target,float)-eye
    forward/=np.linalg.norm(forward)
    right=np.cross(forward,np.asarray(up,float));right/=np.linalg.norm(right)
    down=np.cross(forward,right)
    pose=np.eye(4);pose[:3,:3]=np.column_stack((right,down,forward));pose[:3,3]=eye
    return pose


def intrinsic(width=640,height=480,hfov_deg=90):
    focal=width/(2*np.tan(np.deg2rad(hfov_deg/2)))
    return np.array([[focal,0,(width-1)/2],[0,focal,(height-1)/2],[0,0,1]],float)


class TexturedRayRenderer:
    def __init__(self,scene):
        if isinstance(scene,trimesh.Trimesh):scene=trimesh.Scene(scene)
        self.scene=o3d.t.geometry.RaycastingScene(nthreads=1);self.parts={};self.stats=[];textures={}
        for name in scene.graph.nodes_geometry:
            matrix,geometry_name=scene.graph[name];mesh=scene.geometry[geometry_name]
            if not isinstance(mesh,trimesh.Trimesh) or not len(mesh.faces):continue
            vertices=trimesh.transform_points(mesh.vertices,matrix).astype(np.float32)
            faces=np.asarray(mesh.faces,np.uint32)
            gid=self.scene.add_triangles(o3d.core.Tensor(vertices),o3d.core.Tensor(faces))
            uv=getattr(mesh.visual,'uv',None)
            material=getattr(mesh.visual,'material',None)
            texture=getattr(material,'baseColorTexture',None)
            if texture is None:texture=getattr(material,'image',None)
            if texture is not None and id(texture) not in textures:
                textures[id(texture)]=np.asarray(texture.convert('RGB'))
            image=None if texture is None else textures[id(texture)]
            factor=getattr(material,'baseColorFactor',None)
            if factor is None:factor=np.array([255,255,255,255],np.uint8)
            factor=np.asarray(factor,float)[:3]
            if factor.max()>1:factor=factor/255.
            vertex_colors=None
            if mesh.visual.kind=='vertex':vertex_colors=np.asarray(mesh.visual.vertex_colors)[:,:3]
            face_colors=None
            if mesh.visual.kind=='face':face_colors=np.asarray(mesh.visual.face_colors)[:,:3]
            self.parts[int(gid)]=dict(faces=faces,uv=None if uv is None else np.asarray(uv),
                texture=image,factor=factor,vertex_colors=vertex_colors,face_colors=face_colors)
            self.stats.append(dict(geometry_id=int(gid),node=str(name),geometry=str(geometry_name),
                vertices=len(vertices),triangles=len(faces),visual_kind=mesh.visual.kind,
                texture_shape=None if image is None else list(image.shape)))

    def render(self,intrinsic,world_from_camera,width=640,height=480,max_depth_m=8.,min_depth_m=.1,texture_filter='bilinear'):
        if texture_filter not in ('bilinear','nearest'):raise ValueError('texture_filter must be bilinear or nearest')
        k=np.asarray(intrinsic,float);pose=np.asarray(world_from_camera,float)
        v,u=np.mgrid[:height,:width]
        directions=np.stack(((u-k[0,2])/k[0,0],(v-k[1,2])/k[1,1],np.ones_like(u)),axis=-1)
        rays=np.empty((height,width,6),np.float32);rays[...,:3]=pose[:3,3]
        rays[...,3:]=directions@pose[:3,:3].T
        hits=self.scene.cast_rays(o3d.core.Tensor(rays),nthreads=1)
        depth=hits['t_hit'].numpy();gid=hits['geometry_ids'].numpy();tid=hits['primitive_ids'].numpy()
        bary=hits['primitive_uvs'].numpy();valid=np.isfinite(depth)&(depth>=min_depth_m)&(depth<=max_depth_m)
        rgb=np.zeros((height,width,3),np.uint8)
        for i,part in self.parts.items():
            mask=valid&(gid==i)
            if not np.any(mask):continue
            triangles=part['faces'][tid[mask]]
            t=bary[mask];weights=np.column_stack((1-t.sum(1),t[:,0],t[:,1]))
            if part['texture'] is not None and part['uv'] is not None:
                uv=(part['uv'][triangles]*weights[...,None]).sum(1)
                # glTF textures repeat by default. Keep exact edge coordinate 1
                # on its edge, while wrapping values outside [0,1].
                uv=np.where((uv>=0)&(uv<=1),uv,np.mod(uv,1.))
                image=part['texture'];h,w=image.shape[:2]
                x=np.clip(uv[:,0]*(w-1),0,w-1);y=np.clip((1-uv[:,1])*(h-1),0,h-1)
                x0=np.floor(x).astype(int);y0=np.floor(y).astype(int);x1=np.minimum(x0+1,w-1);y1=np.minimum(y0+1,h-1)
                ax=(x-x0)[:,None];ay=(y-y0)[:,None]
                if texture_filter=='nearest':
                    color=image[np.rint(y).astype(int),np.rint(x).astype(int)]*part['factor']
                else:
                    color=((1-ay)*((1-ax)*image[y0,x0]+ax*image[y0,x1])+ay*((1-ax)*image[y1,x0]+ax*image[y1,x1]))*part['factor']
            elif part['vertex_colors'] is not None:
                color=(part['vertex_colors'][triangles]*weights[...,None]).sum(1)
            elif part['face_colors'] is not None:
                color=part['face_colors'][tid[mask]]
            else:color=np.tile(part['factor']*255,(int(mask.sum()),1))
            rgb[mask]=np.clip(np.rint(color),0,255).astype(np.uint8)
        return dict(rgb=rgb,depth_m=np.where(valid,depth,0.).astype(np.float32),
                    intrinsic=k,world_from_camera=pose,
                    reference_geometry_id=gid,reference_triangle_id=tid,
                    reference_barycentric_uv=bary)
