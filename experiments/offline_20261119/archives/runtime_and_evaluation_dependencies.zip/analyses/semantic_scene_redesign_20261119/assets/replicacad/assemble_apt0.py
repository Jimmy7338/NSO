#!/usr/bin/env python3
"""Read official apt_0 poses and assemble its textured static snapshot.

No policy, physics rollout, robot, or semantic detector is invoked. Articulated
links use URDF joint origins at zero displacement (no initial pose is declared
in apt_0). Source taxonomy and geometry remain evaluator-only metadata.
"""
from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import numpy as np
import trimesh

BASE=Path(__file__).resolve().parent


def read(path):return json.loads(Path(path).read_text())


def numbers(text,default):
    return np.asarray(default if text is None else [float(x) for x in text.replace(',',' ').split()],float)


def placement(instance):
    # Official scene JSON serializes quaternion as [w,x,y,z].
    transform=trimesh.transformations.quaternion_matrix(instance.get('rotation',[1,0,0,0]))
    transform[:3,3]=instance.get('translation',[0,0,0])
    transform[:3,:3]*=float(instance.get('uniform_scale',1))
    return transform


def origin(element):
    out=np.eye(4)
    if element is not None:
        out=trimesh.transformations.euler_matrix(*numbers(element.get('rpy'),[0,0,0]),axes='sxyz')
        out[:3,3]=numbers(element.get('xyz'),[0,0,0])
    return out


def build():
    definition=read(BASE/'configs/scenes/apt_0.scene_instance.json')
    lexicon={x['id']:x['name'] for x in read(BASE/'configs/ssd/replicaCAD_semantic_lexicon.json')['classes']}
    scene=trimesh.Scene();cache={};records=[];node_meta={}
    def append_asset(path,transform,instance_id,category_id,tag):
        path=Path(path).resolve()
        if path not in cache:cache[path]=trimesh.load(path,force='scene',process=False)
        asset=cache[path];points=[]
        for j,node in enumerate(asset.graph.nodes_geometry):
            local,geometry=asset.graph[node];mesh=asset.geometry[geometry]
            name=f'instance_{instance_id:03d}/{tag}/part_{j:03d}'
            combined=transform@local
            scene.add_geometry(mesh,geom_name=name,node_name=name,transform=combined)
            node_meta[name]={'instance_id':instance_id,'source_category_id':category_id,
                'source_asset':str(path.relative_to(BASE))}
            points.extend(trimesh.transform_points(mesh.bounding_box.vertices,combined).tolist())
        return points
    stage=definition['stage_instance'];stage_cfg=read(BASE/('configs/'+stage['template_name']+'.stage_config.json'))
    stage_path=(BASE/('configs/'+stage['template_name']+'.stage_config.json')).parent/stage_cfg['render_asset']
    p=append_asset(stage_path,placement(stage),0,0,'stage')
    records.append({'instance_id':0,'kind':'stage','source_template':stage['template_name'],
        'source_category_id':0,'source_category_name':'unannotated_architecture','bounds_world_xyz_m':[np.min(p,axis=0).tolist(),np.max(p,axis=0).tolist()]})
    for i,instance in enumerate(definition['object_instances'],1):
        cfg_path=BASE/('configs/'+instance['template_name']+'.object_config.json');cfg=read(cfg_path)
        assert np.allclose(cfg['COM'],0),'Nonzero source COM needs explicit adapter'
        category=int(cfg['semantic_id']);p=append_asset(cfg_path.parent/cfg['render_asset'],placement(instance),i,category,'rigid')
        bounds=np.array([np.min(p,axis=0),np.max(p,axis=0)])
        records.append({'instance_id':i,'kind':'rigid','source_template':instance['template_name'],
            'source_category_id':category,'source_category_name':lexicon.get(category,'unknown'),
            'source_pose':instance,'bounds_world_xyz_m':bounds.tolist(),'extent_world_xyz_m':np.ptp(bounds,axis=0).tolist(),
            'nso_open_closed_structure':'unknown_unvalidated'})
    for i,instance in enumerate(definition['articulated_object_instances'],1+len(definition['object_instances'])):
        paths=list((BASE/'urdf').glob('*/'+instance['template_name']+'.urdf'))
        assert len(paths)==1,(instance['template_name'],paths)
        path=paths[0];root=ET.parse(path).getroot();links={x.attrib['name']:x for x in root.findall('link')}
        joints=root.findall('joint');children={x.find('child').attrib['link'] for x in joints}
        base_links=set(links)-children;assert len(base_links)==1
        transforms={next(iter(base_links)):np.eye(4)}
        while len(transforms)<len(links):
            before=len(transforms)
            for joint in joints:
                parent=joint.find('parent').attrib['link'];child=joint.find('child').attrib['link']
                if parent in transforms and child not in transforms:
                    transforms[child]=transforms[parent]@origin(joint.find('origin'))
            assert len(transforms)>before,'Disconnected/cyclic URDF'
        all_points=[]
        for link_name,link in links.items():
            for j,visual in enumerate(link.findall('visual')):
                mesh=visual.find('geometry/mesh');assert mesh is not None,'Primitive visual needs explicit adapter'
                scale=np.eye(4);scale[:3,:3]=np.diag(numbers(mesh.get('scale'),[1,1,1]))
                transform=placement(instance)@transforms[link_name]@origin(visual.find('origin'))@scale
                all_points.extend(append_asset(path.parent/mesh.attrib['filename'],transform,i,0,f'{link_name}_{j}'))
        bounds=np.array([np.min(all_points,axis=0),np.max(all_points,axis=0)])
        records.append({'instance_id':i,'kind':'articulated','source_template':instance['template_name'],
            'source_category_id':0,'source_category_name':'unknown_no_lexicon_id_on_URDF_instance',
            'source_pose':instance,'bounds_world_xyz_m':bounds.tolist(),'extent_world_xyz_m':np.ptp(bounds,axis=0).tolist(),
            'joint_snapshot':'all URDF joint displacements zero','nso_open_closed_structure':'unknown_unvalidated'})
    return scene,records,node_meta


def main():
    scene,records,node_meta=build()
    output=BASE/'preview';output.mkdir(exist_ok=True)
    bounds=np.asarray(scene.bounds,dtype=float)
    assert bounds.shape==(2,3), 'Expected complete 3D scene bounds'
    extent=(bounds[1]-bounds[0]).tolist()
    assert len(extent)==3
    inventory={'source_scene':'apt_0','world_axes':'source Habitat y-up; x/z horizontal; metres',
        'scene_bounds_xyz_m':bounds.tolist(),'scene_extent_xyz_m':extent,
        'geometry_nodes':len(scene.graph.nodes_geometry),'instances':records,'node_metadata':node_meta,
        'rigid_category_instance_counts':dict(Counter(x['source_category_name'] for x in records if x['kind']=='rigid')),
        'room_function_note':'No authoritative room polygons/functional labels are supplied in this selected scene JSON. Furniture co-occurrence supports inferred functional zones only.',
        'assembly_limits':['Static snapshot of official stored poses, no dynamic settling.',
            'URDF links assembled at zero joint displacement; not yet cross-validated against Habitat.',
            'Open/closed structure labels remain unknown until geometry/visibility validation.']}
    (output/'source_inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
    sys.path.insert(0,str(BASE.parent))
    from textured_raycast import TexturedRayRenderer,look_at,intrinsic
    views=[
        {'name':'living','eye':[2.2,1.2,3.4],'target':[2.3,1.0,6.4]},
        {'name':'kitchen','eye':[0.7,1.2,1.2],'target':[-2.0,1.0,1.2]},
        {'name':'work_corner','eye':[2.1,1.2,0.5],'target':[0.4,1.1,-0.2]}]
    (output/'view_manifest.json').write_text(json.dumps({'declared_before_render':True,
        'selection':'Three fixed illustrative views of official furniture groups; no detector or NSO outcome used.',
        'width':640,'height':480,'hfov_deg':90,'views':views},indent=2)+'\n')
    renderer=TexturedRayRenderer(scene);k=intrinsic()
    (output/'render_parts.json').write_text(json.dumps(renderer.stats,indent=2)+'\n')
    from PIL import Image
    rows=[]
    for view in views:
        frame=renderer.render(k,look_at(view['eye'],view['target']))
        instance=np.zeros(frame['depth_m'].shape,np.int32);category=np.zeros_like(instance)
        for part in renderer.stats:
            info=node_meta[part['node']];mask=(frame['reference_geometry_id']==part['geometry_id'])&(frame['depth_m']>0)
            instance[mask]=info['instance_id'];category[mask]=info['source_category_id']
        frame['reference_instance_id']=instance;frame['reference_source_category_id']=category
        np.savez_compressed(output/(view['name']+'.npz'),**frame)
        Image.fromarray(frame['rgb']).save(output/(view['name']+'.png'))
        rows.append({'view':view['name'],'valid_depth_fraction':float(np.mean(frame['depth_m']>0)),
            'visible_source_categories':{str(int(v)):int(np.sum(category==v)) for v in np.unique(category)},
            'rgb_kind':'Unlit original PBR base-color texture sampling; no alpha transparency, lighting or sensor noise.'})
    (output/'render_summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({'bounds':scene.bounds.tolist(),'instance_records':len(records),'geometry_nodes':len(node_meta),'renders':rows}))


if __name__=='__main__':main()
